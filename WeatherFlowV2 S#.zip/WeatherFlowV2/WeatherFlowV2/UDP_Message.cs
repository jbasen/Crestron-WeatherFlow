﻿using System;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;
using Crestron.SimplSharp.Net.Https;
using Crestron.SimplSharp.CrestronSockets;
using System.Collections.Generic;


namespace WeatherFlowV2_Integration
{
	#region Delegates
	public delegate void DelegateFn4(SimplSharpString Event_Time,
	 ushort Lightening_Distance,
	 ushort Lightening_Energy,
	 ushort Wind_Speed,
	 ushort Wind_Direction,
	 ushort Wind_Lull,
	 ushort Wind_Avg,
	 ushort Wind_Gust,
	 ushort Station_Pressure,
	 short Air_Temperature,
	 ushort Relative_Humidity,
	 ushort Illuminance,
	 ushort UV,
	 ushort Solar_Radiation,
	 ushort Precip_Accumulated,
	 ushort Precip_Type,
	 ushort Lightening_Strike_Avg_Distance,
	 ushort Lightening_Strike_Count,
	 ushort Battery,
	 ushort Raining,
	 ushort Not_Raining,
	SimplSharpString Wind_Speed_Units,
	SimplSharpString Pressure_Units,
	SimplSharpString Precip_Units,
	SimplSharpString Distance_Units,
	SimplSharpString Illuminance_Units,
	SimplSharpString UDP_Message_Type,
	SimplSharpString Lightening_Distance_Display_String,
	SimplSharpString Lightening_Energy_Display_String,
	SimplSharpString Wind_Speed_Display_String,
	SimplSharpString Wind_Direction_Display_String,
	SimplSharpString Wind_Lull_Display_String,
	SimplSharpString Wind_Avg_Display_String,
	SimplSharpString Wind_Gust_Display_String,
	SimplSharpString Station_Pressure_Display_String,
	SimplSharpString Air_Temperature_Display_String,
	SimplSharpString Relative_Humidity_Display_String,
	SimplSharpString Illuminance_Display_String,
	SimplSharpString UV_Display_String,
	SimplSharpString Solar_Radiation_Display_String,
	SimplSharpString Precip_Rate_Display_String,
	SimplSharpString Lightening_Strike_Avg_Distance_Display_String,
	SimplSharpString Battery_Display_String);
	#endregion

	#region Enum
	enum Raining_Options
	{
		Unknown,
		Startup,
		TRUE,
		FALSE
	};
	#endregion

	public class UDP_Message
	{
		#region Declarations
		public DelegateFn4 callback_fn4 { get; set; }

		private const int Rounding_Fractional_Digits = 1;
		private static UDPServer UDP_Server;
		private static Data_Format_Options UDP_Display_Format;
		public string WeatherFlow_Hub_IP;
		private const int WeatherFlow_UDP_Port = 50222;
		private static Debug_Options Debug;
		private Raining_Options Raining = Raining_Options.Startup;
		private CTimer cTimer = null;
		private long Stopped_Raining_Timer_MSEC;					//delay in msec
		private UDP_Message_Data message;
		#endregion Declarations

		//****************************************************************************************
		// 
		//  UDP_Initialization	-	Called from s+ to start data collection through
		//							UPD Messages from Station
		// 
		//****************************************************************************************
		public void UDP_Initialization(string WeatherFlow_Hub_IP, int Display_Format, short Stopped_Raining_Timer_Minutes, short Debug)
		{
			#region Save Paramters
			this.WeatherFlow_Hub_IP = WeatherFlow_Hub_IP;
			if (Display_Format == 0)
			{
				UDP_Display_Format = Data_Format_Options.English;
			}
			else if (Display_Format == 1)
			{
				UDP_Display_Format = Data_Format_Options.Metric;
			}
			else
			{
				UDP_Display_Format = Data_Format_Options.English;
			}

			Stopped_Raining_Timer_MSEC = Stopped_Raining_Timer_Minutes  * 60 * 1000;
			#endregion

			Set_Debug_Message_Output(Debug);

			Start_UDP_Receiver(WeatherFlow_Hub_IP, WeatherFlow_UDP_Port);
		}

		//****************************************************************************************
		// 
		//  Start_Stopped_Raining_Timer	-	Start Timer Thread to determine when it stops raining
		// 
		//****************************************************************************************
		private void Start_Done_Raining_Timer()
		{

			if (Stopped_Raining_Timer_MSEC != 0)
			{
				//start the shade management system main worker thread
				if (cTimer == null)
				{
					try
					{
						CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Raining_Timer_Thread);
						cTimer = new CTimer(Raining_Timer_Thread, null, Stopped_Raining_Timer_MSEC);
						Debug_Message("Start_Stopped_Raining_Timer", "Raining Timer Created");

					}
					catch (Exception e)
					{
						Debug_Message("Start_Stopped_Raining_Timer", "Can't create timer thread: " + e + "\n");
						Debug_Message("Start_Stopped_Raining_Timer", "Can't create timer thread: " + e + "\n");
					}
				}
				else
				{
					try
					{
						//restart timer that was previously stopped
						Debug_Message("Start_Stopped_Raining_Timer", "Restarting Timer\n");
						cTimer.Reset(Stopped_Raining_Timer_MSEC);
						Debug_Message("Start_Stopped_Raining_Timer", "Raining Timer Restarted");
					}
					catch (Exception e)
					{
						Debug_Message("Start_Stopped_Raining_Timer", "Can't restart timer thread: " + e + "\n");
						Crestron.SimplSharp.ErrorLog.Error("Start_Stopped_Raining_Timer - Can't restart timer thread: " + e + "\n");
					}
				}
			}
		}

        //****************************************************************************************
        // 
        //  Main_Timer_Thread	-	Main thead performing sun angle calculations
        // 
        //****************************************************************************************
		private void Raining_Timer_Thread(Object unused)
		{
			Debug_Message("Raining_Timer_Thread", "Timer Expired - Raining = false");
			Raining = Raining_Options.FALSE;
			callback_fn4("", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 1, "", "", "", "", "", "evt_not_raining", "", "", "", "", "",
				"", "", "", "", "", "", "", "", "", "", "");

		}

		//****************************************************************************************
		// 
		//  Start_UDP_Receiver	-	Startup Receiver to receive UDP Messages
		// 
		//****************************************************************************************
		private void Start_UDP_Receiver(string Station_IP, int UDP_Port)
		{
			try
			{
				UDP_Server = new UDPServer(IPAddress.Any, UDP_Port, 20000);
				UDP_Server.EnableUDPServer();
				UDP_Server.ReceiveDataAsync(UDP_Receiver_Packet_Received);
			}
			catch (Exception ex)
			{
				string err = "WeatherFlow - Start_UDP_Receiver - Error Starting UDP Receiver: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
		}

		//****************************************************************************************
		// 
		//  UDP_Receiver_Packet_Received	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private void UDP_Receiver_Packet_Received(UDPServer my_UDP_Server, int Byte_Count)
		{
			String str = "";
			try
			{
				Debug_Message("UDP_Receiver_Packet_Received", "Number of Bytes Received: " + Byte_Count + ", From: " + my_UDP_Server.IPAddressLastMessageReceivedFrom);

				Byte[] data = (new List<byte>(my_UDP_Server.IncomingDataBuffer)).ToArray();
				str = System.Text.Encoding.ASCII.GetString(data, 0, Byte_Count);

				#region Parse message if WeatherFlow Hub
				if (my_UDP_Server.IPAddressLastMessageReceivedFrom == WeatherFlow_Hub_IP)
				{

					Debug_Message("UDP_Receiver_Packet_Received", "Data: " + str);

					message = Parse(str);

					UDP_Message_Debug(message);

					#region Pass Back Data to Simplwin
					if ((message.type == "evt_precip") || (message.type == "evt_strike") || (message.type == "rapid_wind")
						|| (message.type == "obs_st") || (message.type == "obs_sky") || (message.type == "obs_air"))
					{
						callback_fn4(message.Event_Time.ToString(),
							Convert.ToUInt16(message.Lightening_Distance),
							Convert.ToUInt16(message.Lightening_Energy),
							Convert.ToUInt16(message.Wind_Speed),
							Convert.ToUInt16(message.Wind_Direction),
							Convert.ToUInt16(message.Wind_Lull),
							Convert.ToUInt16(message.Wind_Avg),
							Convert.ToUInt16(message.Wind_Gust),
							Convert.ToUInt16(message.Station_Pressure),
							Convert.ToInt16(message.Air_Temperature),
							Convert.ToUInt16(message.Relative_Humidity),
							Convert.ToUInt16(message.Illuminance),
							Convert.ToUInt16(message.UV),
							Convert.ToUInt16(message.Solar_Radiation),
							Convert.ToUInt16(message.Precip_Rate),
							Convert.ToUInt16(message.Precip_Type),
							Convert.ToUInt16(message.Lightening_Strike_Avg_Distance),
							Convert.ToUInt16(message.Lightening_Strike_Count),
							Convert.ToUInt16(message.Battery),
							Convert.ToUInt16((Raining == Raining_Options.TRUE) ? 1 : 0),
							Convert.ToUInt16((Raining == Raining_Options.FALSE) ? 1 : 0),
							message.Wind_Speed_Units,
							message.Pressure_Units,
							message.Precip_Units,
							message.Distance_Units,
							message.Illuminance_Units,
							message.type,
							message.Lightening_Distance_Display_String,
							message.Lightening_Energy_Display_String,
							message.Wind_Speed_Display_String,
							message.Wind_Direction_Display_String,
							message.Wind_Lull_Display_String,
							message.Wind_Avg_Display_String,
							message.Wind_Gust_Display_String,
							message.Station_Pressure_Display_String,
							message.Air_Temperature_Display_String,
							message.Relative_Humidity_Display_String,
							message.Illuminance_Display_String,
							message.UV_Display_String,
							message.Solar_Radiation_Display_String,
							message.Precip_Rate_Display_String,
							message.Lightening_Strike_Avg_Distance_Display_String,
							message.Battery_Display_String);
					}
					#endregion
				}
				else
				{
					Debug_Message("UDP_Receiver_Packet_Received", "Message Received from Unknown IP Address: " + my_UDP_Server.IPAddressLastMessageReceivedFrom);
					Debug_Message("UDP_Receiver_Packet_Received", "Message Received from Unknown Contents: " + str);
				}
				#endregion
			}
			catch (Exception ex)
			{
				#region Save Exception Data
				string err = "WeatherFlow - UDP_Receiver_Packet_Received - Error Retreiving UDP_Message: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("WeatherFlow - UDP_Receiver_Packet_Received - \n" + ex.StackTrace);
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - JSON: " + str + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Event_Time: " + message.Event_Time.ToString() + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Lightening_Distance: " + message.Lightening_Distance + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Lightening_Energy: " + message.Lightening_Energy + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Wind_Speed: " + message.Wind_Speed + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Wind_Direction: " + message.Wind_Direction + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Wind_Lull: " + message.Wind_Lull + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Wind_Avg: " + message.Wind_Avg + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Wind_Gust: " + message.Wind_Gust + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Station_Pressure: " + message.Station_Pressure + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Air_Temperature: " + message.Air_Temperature + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Relative_Humidity: " + message.Relative_Humidity + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Illuminance: " + message.Illuminance + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - UV: " + message.UV + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Solar_Radiation: " + message.Solar_Radiation + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Precip_Rate: " + message.Precip_Rate + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Precip_Type: " + message.Precip_Type + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Lightening_Strike_Avg_Distance: " + message.Lightening_Strike_Avg_Distance + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Lightening_Strike_Count: " + message.Lightening_Strike_Count + "\n");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - UDP_Receiver_Packet_Received - Battery: " + message.Battery + "\n");
				#endregion
			}

			my_UDP_Server.ReceiveDataAsync(UDP_Receiver_Packet_Received);
		}

		//****************************************************************************************
		// 
		//  Parse	-   Parse UDP Message
		// 
		//****************************************************************************************
		private UDP_Message_Data Parse(string json)
		{
			Debug_Message("Parse", "json = " + json);

			#region Fix Json So Newtonsoft Can Parse It
			json = json.Replace("[[", "[");
			json = json.Replace("]]", "]");
			#endregion Fix Json So Newtonsoft Can Parse It

			try
			{
				UDP_Message_Data item = JsonConvert.DeserializeObject<UDP_Message_Data>(json);

				#region Validate Parsing
				if (item == null)
				{
					Debug_Message("Parse", "Error Parsing JSON = " + json);
					return null;
				}
				else
				{
					Debug_Message("Parse", "Successfully Parsed JSON");
				}
				#endregion Validate Parsing

				#region Parse List Data
				if (item.type == "evt_precip")
				{
					Debug_Message("Parse", "EVT_PRECIP");
					item.Event_Time = Epoch_Conversion(item.evt[0]);
					Raining = Raining_Options.TRUE;
					Start_Done_Raining_Timer();
				}
				else if (item.type == "evt_strike")
				{
					Debug_Message("Parse", "EVT_STRIKE");
					item.Event_Time = Epoch_Conversion(item.evt[0]);
					item.Lightening_Distance = item.evt[1];
					item.Lightening_Energy = item.evt[2];
					Raining = Raining_Options.Unknown;
				}
				else if (item.type == "rapid_wind")
				{
					Debug_Message("Parse", "rapid_wind");
					item.Event_Time = Epoch_Conversion(item.ob[0]);
					item.Wind_Speed = item.ob[1];
					item.Wind_Direction = Convert.ToInt32(item.ob[2]);
					Raining = Raining_Options.Unknown;
				}
				else if (item.type == "obs_st")
				{
					Debug_Message("Parse", "obs_st");
					item.Event_Time = Epoch_Conversion(item.obs[0]);
					item.Wind_Lull = item.obs[1];
					item.Wind_Avg = item.obs[2];
					item.Wind_Gust = item.obs[3];
					item.Wind_Direction = Convert.ToInt32(item.obs[4]);
					item.Wind_Sample_Interval = item.obs[5];
					item.Station_Pressure = item.obs[6];
					item.Air_Temperature = item.obs[7];
					item.Relative_Humidity = item.obs[8];
					item.Illuminance = item.obs[9];
					item.UV = item.obs[10];
					item.Solar_Radiation = item.obs[11];
					item.Precip_Rate = item.obs[12];
					item.Precip_Type = Convert.ToInt32(item.obs[13]);
					item.Lightening_Strike_Avg_Distance = item.obs[14];
					item.Lightening_Strike_Count = Convert.ToInt32(item.obs[15]);
					item.Battery = item.obs[16];
					item.Report_Interval = Convert.ToInt32(item.obs[17]);

					#region Still Raining?
					if ((item.Precip_Rate > 0) || (item.Precip_Type != 0))
					{
						Debug_Message("Parse", "Precip_rate = " + item.Precip_Rate + ", Precip_Type = " + item.Precip_Type + " - Still Raining");
						if (Raining == Raining_Options.Startup)
						{
							callback_fn4("", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
								1, 0, "", "", "", "", "", "evt_startup", "", "", "", "", "",
								"", "", "", "", "", "", "", "", "", "", "");
						}
						Raining = Raining_Options.TRUE;
						Start_Done_Raining_Timer();
					}
					else
					{
						if (Raining == Raining_Options.Startup)
						{
							callback_fn4("", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
								0, 1, "", "", "", "", "", "evt_startup", "", "", "", "", "",
								"", "", "", "", "", "", "", "", "", "", "");
						}
						Raining = Raining_Options.Unknown;
					}
					#endregion

				}
				else if (item.type == "obs_sky")
				{
					Debug_Message("Parse", "obs_sky");
					item.Event_Time = Epoch_Conversion(item.obs[0]);
					item.Wind_Lull = item.obs[4];
					item.Wind_Avg = item.obs[5];
					item.Wind_Gust = item.obs[6];
					item.Wind_Direction = Convert.ToInt32(item.obs[7]);
					item.Wind_Sample_Interval = item.obs[13];
					item.Illuminance = item.obs[1];
					item.UV = item.obs[2];
					item.Solar_Radiation = item.obs[10];
					item.Precip_Rate = item.obs[11];
					item.Precip_Type = Convert.ToInt32(item.obs[3]);
					item.Battery = item.obs[8];
					item.Report_Interval = Convert.ToInt32(item.obs[9]);

					#region Still Raining?
					if ((item.Precip_Rate > 0) || (item.Precip_Type != 0))
					{
						Debug_Message("Parse", "Precip_rate = " + item.Precip_Rate + ", Precip_Type = " + item.Precip_Type + " - Still Raining");
						if (Raining == Raining_Options.Startup)
						{
							callback_fn4("", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
								1, 0, "", "", "", "", "", "evt_startup", "", "", "", "", "",
								"", "", "", "", "", "", "", "", "", "", "");
						}
						Raining = Raining_Options.TRUE;
						Start_Done_Raining_Timer();
					}
					else
					{
						if (Raining == Raining_Options.Startup)
						{
							callback_fn4("", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
								0, 1, "", "", "", "", "", "evt_startup", "", "", "", "", "",
								"", "", "", "", "", "", "", "", "", "", "");
						}
						Raining = Raining_Options.Unknown;
					}
					#endregion
				}
				else if (item.type == "obs_air")
				{
					Debug_Message("Parse", "obs_air");
					item.Event_Time = Epoch_Conversion(item.obs[0]);
					item.Station_Pressure = item.obs[1];
					item.Air_Temperature = item.obs[2];
					item.Relative_Humidity = item.obs[3];
					item.Lightening_Strike_Avg_Distance = item.obs[5];
					item.Lightening_Strike_Count = Convert.ToInt32(item.obs[4]);
					item.Battery = item.obs[6];
					item.Report_Interval = Convert.ToInt32(item.obs[7]);
					Raining = Raining_Options.Unknown;
				}
				else
				{
					Debug_Message("Parse", string.Format("unsupported message type = " + item.type));
					Raining = Raining_Options.Unknown;
				}

				#endregion Parse List Data

				#region Data Conversion
				if (UDP_Display_Format == Data_Format_Options.English)
				{
					item.Wind_Lull *= 2.237;//meters per second to mph
					item.Wind_Avg *= 2.237;//meters per second to mph
					item.Wind_Gust *= 2.237;//meters per second to mph
					item.Station_Pressure /= 33.864;//millibars to inches of mercury
					item.Air_Temperature = (item.Air_Temperature) * 1.8 + 32;//Celcius to Fahrenheit
					item.Precip_Rate /= 25.4;//mm to inches
					item.Precip_Rate *= 60;//per minute to per hour
					item.Lightening_Strike_Avg_Distance /= 1.609;//km to miles
					item.Lightening_Distance /= 1.609;//km to miles
					item.Wind_Speed *= 2.237;//meters per second to mph
				}
				else
				{
					item.Wind_Lull *= 3.6;//meters per second to km/h
					item.Wind_Avg *= 3.6;//meters per second to km/h
					item.Wind_Gust *= 3.6;//meters per second to km/h
					item.Wind_Speed *= 3.6;//meters per second to km/h
					item.Precip_Rate *= 60;//per minute to per hour
				}
				#endregion Data Conversion

				#region Set Units
				if (UDP_Display_Format == Data_Format_Options.English)
				{
					//item.Wind_Speed_Units = device.MPH_Translation_Property.Value; BUG - Doesn't Work
					item.Wind_Speed_Units = "mph";
					item.Pressure_Units = "inhg";
					item.Precip_Units = "in";
					item.Distance_Units = "miles";
				}
				else
				{
					//TODO get from translations
					item.Wind_Speed_Units = "km/h";
					item.Pressure_Units = "mb";
					item.Precip_Units = "mm";
					item.Distance_Units = "km";
				}
				#endregion Set Units

				#region Illuminance
				item.Illuminance /= 10;
				item.Illuminance_Units = "dlux";
				#endregion

				#region Round Data Elements
				item.Lightening_Distance = Math.Round(item.Lightening_Distance, Rounding_Fractional_Digits);
				item.Lightening_Energy = Math.Round(item.Lightening_Energy, Rounding_Fractional_Digits);
				item.Wind_Speed = Math.Round(item.Wind_Speed, Rounding_Fractional_Digits);
				item.Wind_Lull = Math.Round(item.Wind_Lull, Rounding_Fractional_Digits);
				item.Wind_Avg = Math.Round(item.Wind_Avg, Rounding_Fractional_Digits);
				item.Wind_Gust = Math.Round(item.Wind_Gust, Rounding_Fractional_Digits);
				item.Wind_Sample_Interval = Math.Round(item.Wind_Sample_Interval, Rounding_Fractional_Digits);
				item.Station_Pressure = Math.Round(item.Station_Pressure, Rounding_Fractional_Digits);
				item.Air_Temperature = Math.Round(item.Air_Temperature, Rounding_Fractional_Digits);
				item.Relative_Humidity = Math.Round(item.Relative_Humidity, Rounding_Fractional_Digits);
				item.UV = Math.Round(item.UV, Rounding_Fractional_Digits);
				item.Solar_Radiation = Math.Round(item.Solar_Radiation, Rounding_Fractional_Digits);
				item.Precip_Rate = Math.Round(item.Precip_Rate, Rounding_Fractional_Digits);
				item.Lightening_Strike_Avg_Distance = Math.Round(item.Lightening_Strike_Avg_Distance, Rounding_Fractional_Digits);
				item.Battery = Math.Round(item.Battery, Rounding_Fractional_Digits);
				#endregion Round Data Elements

				#region Create Display Strings
				item.Lightening_Distance_Display_String = item.Lightening_Distance.ToString() + " " + item.Distance_Units;
				item.Lightening_Energy_Display_String = item.Lightening_Energy.ToString();
				item.Wind_Speed_Display_String = item.Wind_Speed.ToString() + " " + item.Wind_Speed_Units;
				item.Wind_Direction_Display_String = Degrees_To_Cardinal_Direction(item.Wind_Direction);
				item.Wind_Lull_Display_String = item.Wind_Lull.ToString() + " " + item.Wind_Speed_Units;
				item.Wind_Avg_Display_String = item.Wind_Avg.ToString() + " " + item.Wind_Speed_Units;
				item.Wind_Gust_Display_String = item.Wind_Gust.ToString() + " " + item.Wind_Speed_Units;
				item.Station_Pressure_Display_String = item.Station_Pressure.ToString() + " " + item.Pressure_Units;
				item.Air_Temperature_Display_String = item.Air_Temperature.ToString() + " Degrees";
				item.Relative_Humidity_Display_String = item.Relative_Humidity.ToString() + "%";
				item.Illuminance_Display_String = item.Illuminance.ToString() + " " + item.Illuminance_Units;
				item.UV_Display_String = item.UV.ToString();
				item.Solar_Radiation_Display_String = item.Solar_Radiation.ToString() + " W/m^2";
				item.Precip_Rate_Display_String = item.Precip_Rate.ToString() + " " + item.Precip_Units + "/hour";
				item.Lightening_Strike_Avg_Distance_Display_String = item.Lightening_Strike_Avg_Distance.ToString() + " " + item.Distance_Units;
				item.Battery_Display_String = item.Battery.ToString() + " Volts";
				#endregion

				return item;
			}
			catch (Exception ex)
			{
				string err = "WeatherFlow - UDP_Message - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("WeatherFlow - UDP_Message - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}

		//****************************************************************************************
		// 
		//  UDP_Message_Debug	-   Send Message Data to Debug_Message
		// 
		//****************************************************************************************
		private void UDP_Message_Debug(UDP_Message_Data message)
		{
			Debug_Message("UDP_Message_Debug", "Event_Time: " + message.Event_Time.ToString());
			Debug_Message("UDP_Message_Debug", "Lightening_Distance: " + message.Lightening_Distance);
			Debug_Message("UDP_Message_Debug", "Lightening_Energy: " + message.Lightening_Energy);
			Debug_Message("UDP_Message_Debug", "Wind_Speed: " + message.Wind_Speed);
			Debug_Message("UDP_Message_Debug", "Wind_Direction: " + message.Wind_Direction);
			Debug_Message("UDP_Message_Debug", "Wind_Lull: " + message.Wind_Lull);
			Debug_Message("UDP_Message_Debug", "Wind_Avg: " + message.Wind_Avg);
			Debug_Message("UDP_Message_Debug", "Wind_Gust: " + message.Wind_Gust);
			Debug_Message("UDP_Message_Debug", "Station_Pressure: " + message.Station_Pressure);
			Debug_Message("UDP_Message_Debug", "Air_Temperature: " + message.Air_Temperature);
			Debug_Message("UDP_Message_Debug", "Relative_Humidity: " + message.Relative_Humidity);
			Debug_Message("UDP_Message_Debug", "Illuminance: " + message.Illuminance);
			Debug_Message("UDP_Message_Debug", "UV: " + message.UV);
			Debug_Message("UDP_Message_Debug", "Solar_Radiation: " + message.Solar_Radiation);
			Debug_Message("UDP_Message_Debug", "Precip_Rate: " + message.Precip_Rate);
			Debug_Message("UDP_Message_Debug", "Precip_Type: " + message.Precip_Type);
			Debug_Message("UDP_Message_Debug", "Lightening_Strike_Avg_Distance: " + message.Lightening_Strike_Avg_Distance);
			Debug_Message("UDP_Message_Debug", "Lightening_Strike_Count: " + message.Lightening_Strike_Count);
			Debug_Message("UDP_Message_Debug", "Battery: " + message.Battery);
		}

		//****************************************************************************************
		// 
		//  Epoch_Conversion	-   
		// 
		//****************************************************************************************
		private static DateTime Epoch_Conversion(double Epoch)
		{
			// Unix timestamp is seconds past epoch
			DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
			dtDateTime = dtDateTime.AddSeconds(Convert.ToInt32(Epoch)).ToLocalTime();

			return dtDateTime;
		}

		//****************************************************************************************
		// 
		//  Degrees_To_Cardinal_Direction	-	Convert from Degrees to Cardinal Direction
		// 
		//****************************************************************************************
		private static string Degrees_To_Cardinal_Direction(int degrees)
		{
			if ((degrees >= 348.75) && (degrees < 11.25))
			{
				return "N";
			}
			else if ((degrees >= 11.25) && (degrees < 33.75))
			{
				return "NNE";
			}
			else if ((degrees >= 33.75) && (degrees < 56.25))
			{
				return "NE";
			}
			else if ((degrees >= 56.25) && (degrees < 78.75))
			{
				return "ENE";
			}
			else if ((degrees >= 78.75) && (degrees < 101.25))
			{
				return "E";
			}
			else if ((degrees >= 101.25) && (degrees < 123.75))
			{
				return "ESE";
			}
			else if ((degrees >= 123.75) && (degrees < 146.25))
			{
				return "SE";
			}
			else if ((degrees >= 146.25) && (degrees < 168.75))
			{
				return "SSE";
			}
			else if ((degrees >= 168.75) && (degrees < 191.25))
			{
				return "S";
			}
			else if ((degrees >= 191.25) && (degrees < 213.75))
			{
				return "SSW";
			}
			else if ((degrees >= 213.75) && (degrees < 236.25))
			{
				return "SW";
			}
			else if ((degrees >= 236.25) && (degrees < 258.75))
			{
				return "WSW";
			}
			else if ((degrees >= 258.75) && (degrees < 281.25))
			{
				return "W";
			}
			else if ((degrees >= 281.25) && (degrees < 303.75))
			{
				return "WNW";
			}
			else if ((degrees >= 303.75) && (degrees < 326.25))
			{
				return "NW";
			}
			else if ((degrees >= 326.25) && (degrees < 348.75))
			{
				return "NNW";
			}
			else
			{
				return degrees.ToString() + " Degrees";
			}
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		private static void Set_Debug_Message_Output(short Debug_Level)
		{
			//Save debug message setting as an enum
			switch (Debug_Level)
			{
				case 0:
					Debug = Debug_Options.None;
					break;

				case 1:
					Debug = Debug_Options.Console;
					break;

				case 2:
					Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private static void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("WeatherFlow UDP Data - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("WeatherFlow UDP Data - "  + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

	}

	#region UPD Classes
	public class UDP_Message_Data
	{
		public string serial_number { get; set; }
		public string type { get; set; }
		public string hub_sn { get; set; }
		public IList<double> evt { get; set; }
		public IList<double> ob { get; set; }
		public IList<double> obs { get; set; }
		public string firmware_revision { get; set; }

		//Elements Parsed from above json elements

		public DateTime Event_Time;

		//Lighening Strike Event
		public double Lightening_Distance;
		public double Lightening_Energy;

		//Rapid Wind Event
		public double Wind_Speed;
		public int Wind_Direction;

		//Observation
		public double Wind_Lull;
		public double Wind_Avg;
		public double Wind_Gust;
		public double Wind_Sample_Interval;
		public double Station_Pressure;
		public double Air_Temperature;
		public double Relative_Humidity;
		public double Illuminance;
		public double UV;
		public double Solar_Radiation;
		public double Precip_Rate;
		public int Precip_Type;
		public double Lightening_Strike_Avg_Distance;
		public int Lightening_Strike_Count;
		public double Battery;
		public int Report_Interval;

		//Display Units Strings
		public string Wind_Speed_Units;
		public string Pressure_Units;
		public string Precip_Units;
		public string Distance_Units;
		public string Illuminance_Units;

		//Display Strings
		public string Lightening_Distance_Display_String;
		public string Lightening_Energy_Display_String;
		public string Wind_Speed_Display_String;
		public string Wind_Direction_Display_String;
		public string Wind_Lull_Display_String;
		public string Wind_Avg_Display_String;
		public string Wind_Gust_Display_String;
		public string Wind_Sample_Interval_Display_String;
		public string Station_Pressure_Display_String;
		public string Air_Temperature_Display_String;
		public string Relative_Humidity_Display_String;
		public string Illuminance_Display_String;
		public string UV_Display_String;
		public string Solar_Radiation_Display_String;
		public string Precip_Rate_Display_String;
		public string Lightening_Strike_Avg_Distance_Display_String;
		public string Battery_Display_String;
	}
	#endregion
}