﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace WeatherFlowV2
{
	public class UDP_Message
	{
		#region Declarations
		public string serial_number { get; set; }
		public string type { get; set; }
		public string hub_sn { get; set; }
		public IList<double> evt { get; set; }
		public IList<double> ob { get; set; }
		public IList<double> obs { get; set; }
		public string firmware_revision { get; set; }

		//Elements Parsed from above json elements

		public DateTime Event_Time;

		//Lighening Strike Event
		public double Lightening_Distance;
		public double Lightening_Energy;

		//Rapid Wind Event
		public double Wind_Speed;
		public int Wind_Direction;

		//Tempest Observation
		public double Wind_Lull;
		public double Wind_Avg;
		public double Wind_Gust;
		public double Wind_Sample_Interval;
		public double Station_Pressure;
		public double Air_Temperature;
		public double Relative_Humidity;
		public double Illuminance;
		public double UV;
		public double Solar_Radiation;
		public double Precip_Accumulated;
		public int Precip_Type;
		public double Lightening_Strike_Avg_Distance;
		public int Lightening_Strike_Count;
		public double Battery;
		public int Report_Interval;

		//Other
		public bool Raining;

		//Display Units Strings
		public string Wind_Speed_Units;
		public string Pressure_Units;
		public string Precip_Units;
		public string Distance_Units;
		public string Illuminance_Units;

		//Internal
		private const int Rounding_Fractional_Digits = 0;
		#endregion Declarations

		//****************************************************************************************
		// 
		//  Parse	-   Parse UDP Message
		// 
		//****************************************************************************************
		public static UDP_Message Parse(string json)
		{
			CrestronConsole.PrintLine("UDP_Message.Parse - " + json);

			#region Fix Json So Newtonsoft Can Parse It
			json = json.Replace("[[", "[");
			json = json.Replace("]]", "]");
			#endregion Fix Json So Newtonsoft Can Parse It

			try
			{
				UDP_Message item = JsonConvert.DeserializeObject<UDP_Message>(json);

				#region Validate Parsing
				if (item == null)
				{
					CrestronConsole.PrintLine("UDP_Message - Parse - Error Parsing JSON");
					return null;
				}
				else
				{
					CrestronConsole.PrintLine("UDP_Message - Parse - Successfully Parsed JSON");
				}
				#endregion Validate Parsing

				item.Raining = false;

				#region Parse List Data
				if (item.type == "evt_precip")
				{
					item.Event_Time = Epoch_Conversion(item.evt[0]);
					item.Raining = true;
				}
				else if (item.type == "evt_strike")
				{
					item.Event_Time = Epoch_Conversion(item.evt[0]);
					item.Lightening_Distance = item.evt[1];
					item.Lightening_Energy = item.evt[2];
				}
				else if (item.type == "rapid_wind")
				{
					item.Event_Time = Epoch_Conversion(item.ob[0]);
					item.Wind_Speed = item.ob[1];
					item.Wind_Direction = Convert.ToInt32(item.ob[2]);
				}
				else if (item.type == "obs_st")
				{
					item.Event_Time = Epoch_Conversion(item.obs[0]);
					item.Wind_Lull = item.obs[1];
					item.Wind_Avg = item.obs[2];
					item.Wind_Gust = item.obs[3];
					item.Wind_Direction = Convert.ToInt32(item.obs[4]);
					item.Wind_Sample_Interval = item.obs[5];
					item.Station_Pressure = item.obs[6];
					item.Air_Temperature = item.obs[7];
					item.Relative_Humidity = item.obs[8];
					item.Illuminance = item.obs[9];
					item.UV = item.obs[10];
					item.Solar_Radiation = item.obs[11];
					item.Precip_Accumulated = item.obs[12];
					item.Precip_Type = Convert.ToInt32(item.obs[13]);
					item.Lightening_Strike_Avg_Distance = item.obs[14];
					item.Lightening_Strike_Count = Convert.ToInt32(item.obs[15]);
					item.Battery = item.obs[16];
					item.Report_Interval = Convert.ToInt32(item.obs[17]);
				}
				else
				{
					CrestronConsole.PrintLine("UDP_Message - Parse - " + string.Format("unsupported message type = " + item.type));
				}
				#endregion Parse List Data

				#region Data Conversion
				if (WeatherFlowV2_Integration.UDP_Display_Format == UDP_Display_Formats.English)
				{
					item.Wind_Lull *= 2.237;//meters per second to mph
					item.Wind_Avg *= 2.237;//meters per second to mph
					item.Wind_Gust *= 2.237;//meters per second to mph
					item.Station_Pressure /= 33.864;//millibars to inches of mercury
					item.Air_Temperature = (item.Air_Temperature) * 1.8 + 32;//Celcius to Fahrenheit
					item.Precip_Accumulated /= 25.4;//mm to inches
					item.Lightening_Strike_Avg_Distance /= 1.609;//km to miles
					item.Lightening_Distance /= 1.609;//km to miles
					item.Wind_Speed *= 2.237;//meters per second to mph
				}
				else
				{
					item.Wind_Lull *= 3.6;//meters per second to km/h
					item.Wind_Avg *= 3.6;//meters per second to km/h
					item.Wind_Gust *= 3.6;//meters per second to km/h
					item.Wind_Speed *= 3.6;//meters per second to km/h
				}
				#endregion Data Conversion

				#region Set Units
				if (WeatherFlowV2_Integration.UDP_Display_Format == UDP_Display_Formats.English)
				{
					//item.Wind_Speed_Units = device.MPH_Translation_Property.Value; BUG - Doesn't Work
					item.Wind_Speed_Units = "mph";
					item.Pressure_Units = "inhg";
					item.Precip_Units = "in";
					item.Distance_Units = "miles";
				}
				else
				{
					//TODO get from translations
					item.Wind_Speed_Units = "km/h";
					item.Pressure_Units = "mb";
					item.Precip_Units = "mm";
					item.Distance_Units = "km";
				}
				#endregion Set Units

				#region Illuminance
				if (item.Illuminance > 30000)				//avoid int16 data overflow
				{
					item.Illuminance /= 1000;
					item.Illuminance = Math.Round(item.Illuminance, Rounding_Fractional_Digits);
					item.Illuminance_Units = "kilolux";
				}
				else
				{
					item.Illuminance_Units = "lux";
				}
				#endregion

				#region Round Data Elements
				item.Lightening_Distance = Math.Round(item.Lightening_Distance, Rounding_Fractional_Digits);
				item.Lightening_Energy = Math.Round(item.Lightening_Energy, Rounding_Fractional_Digits);
				item.Wind_Speed = Math.Round(item.Wind_Speed, Rounding_Fractional_Digits);
				item.Wind_Lull = Math.Round(item.Wind_Lull, Rounding_Fractional_Digits);
				item.Wind_Avg = Math.Round(item.Wind_Avg, Rounding_Fractional_Digits);
				item.Wind_Gust = Math.Round(item.Wind_Gust, Rounding_Fractional_Digits);
				item.Wind_Sample_Interval = Math.Round(item.Wind_Sample_Interval, Rounding_Fractional_Digits);
				item.Station_Pressure = Math.Round(item.Station_Pressure, Rounding_Fractional_Digits);
				item.Air_Temperature = Math.Round(item.Air_Temperature, Rounding_Fractional_Digits);
				item.Relative_Humidity = Math.Round(item.Relative_Humidity, Rounding_Fractional_Digits);
				item.UV = Math.Round(item.UV, Rounding_Fractional_Digits);
				item.Solar_Radiation = Math.Round(item.Solar_Radiation, Rounding_Fractional_Digits);
				item.Precip_Accumulated = Math.Round(item.Precip_Accumulated, Rounding_Fractional_Digits);
				item.Lightening_Strike_Avg_Distance = Math.Round(item.Lightening_Strike_Avg_Distance, Rounding_Fractional_Digits);
				item.Battery = Math.Round(item.Battery, Rounding_Fractional_Digits);
				#endregion Round Data Elements

				return item;
			}
			catch (Exception ex)
			{
				string err = "WeatherFlow - UDP_Message - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("WeatherFlow - UDP_Message - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}

		//****************************************************************************************
		// 
		//  Epoch_Conversion	-   
		// 
		//****************************************************************************************
		private static DateTime Epoch_Conversion(double Epoch)
		{
			// Unix timestamp is seconds past epoch
			DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
			dtDateTime = dtDateTime.AddSeconds(Convert.ToInt32(Epoch)).ToLocalTime();

			return dtDateTime;
		}
	}
}