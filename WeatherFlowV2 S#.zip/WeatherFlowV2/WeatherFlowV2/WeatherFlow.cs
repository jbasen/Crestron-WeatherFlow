﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;
using Crestron.SimplSharp.CrestronSockets;
using System.Collections.Generic;

namespace WeatherFlowV2
{

	#region Delegates
	public delegate void DelegateFn(SimplSharpString Station_Name, ushort Station_Name_Valid,
		SimplSharpString Latitude, ushort Latitude_Valid,
		SimplSharpString Longitude, ushort Longitude_Valid,
		SimplSharpString Elevation, ushort Elevation_Valid,
		SimplSharpString Time_Stamp, ushort Time_Stamp_Valid,
		SimplSharpString Air_Temperature, short Air_Temperature_Value, ushort Air_Temperature_Valid,
		SimplSharpString Heat_Index, short Heat_Index_Value, ushort Heat_Index_Valid,
		SimplSharpString Station_Pressure, short Station_Pressure_Value, ushort Station_Pressure_Valid,
		SimplSharpString Surface_Pressure, short Surface_Pressure_Value, ushort Surface_Pressure_Valid,
		SimplSharpString Relative_Humidity, short Relative_Humidity_Value, ushort Relative_Humidity_Valid,
		SimplSharpString Precipitation, short Precipitation_Value, ushort Precipitation_Valid,
		SimplSharpString Precipitation_Accumulation_Last_1hr, short Precipitation_Accumulation_Last_1hr_Value, ushort Precipitation_Accumulation_Last_1hr_Valid,
		SimplSharpString Wind_Average, short Wind_Average_Value, ushort Wind_Average_Valid,
		SimplSharpString Wind_Direction, short Wind_Direction_Value, ushort Wind_Direction_Valid,
		SimplSharpString Wind_Gust, short Wind_Gust_Value, ushort Wind_Gust_Valid,
		SimplSharpString Wind_Lull, short Wind_Lull_Value, ushort Wind_Lull_Valid,
		SimplSharpString Solar_Radiation, short Solar_Radiation_Value, ushort Solar_Radiation_Valid,
		SimplSharpString UV, short UV_Value, ushort UV_Valid,
		SimplSharpString Lightening_Strike_Count, short Lightening_Strike_Count_Value, ushort Lightening_Strike_Count_Valid,
		SimplSharpString Lightening_Strike_Count_Last_3hr, short Lightening_Strike_Count_Last_3hr_Value, ushort Lightening_Strike_Count_Last_3hr_Valid,
		SimplSharpString Lightening_Strike_Last_Distance, short Lightening_Strike_Last_Distance_Value, ushort Lightening_Strike_Last_Distance_Valid,
		SimplSharpString Sky_Battery_Voltage, short Sky_Battery_Voltage_Value, ushort Sky_Battery_Voltage_Valid,
		SimplSharpString Air_Battery_Voltage, short Air_Battery_Voltage_Value, ushort Air_Battery_Voltage_Valid,
		SimplSharpString Tempest_Battery_Voltage, short Tempest_Battery_Voltage_Value, ushort Tempest_Battery_Voltage_Valid,
		SimplSharpString Precipitation_Accumulation_Local_Day, short Precipitation_Accumulation_Local_Day_Value, ushort Precipitation_Accumulation_Local_Day_Valid,
		SimplSharpString Precipitation_Accumulation_Local_Yesterday, short Precipitation_Accumulation_Local_Yesterday_Value, ushort Precipitation_Accumulation_Local_Yesterday_Valid,
		SimplSharpString Precipitation_Minutes_Local_Day, short Precipitation_Minutes_Local_Day_Value, ushort Precipitation_Minutes_Local_Day_Valid,
		SimplSharpString Precipitation_Minutes_Local_Yesterday, short Precipitation_Minutes_Local_Yesterday_Value, ushort Precipitation_Minutes_Local_Yesterday_Valid,
		SimplSharpString Lightening_Strike_Avg_Distance, short Lightening_Strike_Avg_Distance_Value, ushort Lightening_Strike_Avg_Distance_Valid,
		SimplSharpString Illuminance, short Illuminance_Value, ushort Illuminance_Valid,
		SimplSharpString Precipitation_Type, short Precipitation_Type_Value, ushort Precipitation_Type_Valid);

	public delegate void DelegateFn4(SimplSharpString Event_Time,
		 ushort Lightening_Distance,
		 ushort Lightening_Energy,
		 ushort Wind_Speed,
		 ushort Wind_Direction,
		 ushort Wind_Lull,
		 ushort Wind_Avg,
		 ushort Wind_Gust,
		 ushort Station_Pressure,
		 short Air_Temperature,
		 ushort Relative_Humidity,
		 ushort Illuminance,
		 ushort UV,
		 ushort Solar_Radiation,
		 ushort Precip_Accumulated,
		 ushort Precip_Type,
		 ushort Lightening_Strike_Avg_Distance,
		 ushort Lightening_Strike_Count,
		 ushort Battery,
		 ushort Raining,
		SimplSharpString Wind_Speed_Units,
		SimplSharpString Pressure_Units,
		SimplSharpString Precip_Units,
		SimplSharpString Distance_Units,
		SimplSharpString Illuminance_Units
);

	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};

	enum Temperature_Format_Options
	{
		Celsius,
		Fahrenheit
	};

	public enum UDP_Display_Formats
	{
		English,
		Metric
	};
	#endregion

	public class WeatherFlowV2_Integration
	{
		public DelegateFn callback_fn { get; set; }
		public DelegateFn4 callback_fn4 { get; set; }

		public WeatherFlowV2_Integration()
		{
		}

		#region Declarations
		private string Station_ID;
		private string API_Key;
		private string Air_Device_ID;
		private string Sky_Device_ID;
		private string Tempest_Device_ID;
		private Debug_Options Debug;

		private long delay_between_calculations = 900000;						// 15 minute delay in msec 15 minutes * 60 seconds * 1000 msec
		private CTimer cTimer = null;											//timer thread for evaluating sun angle 

		private string Station_Name;
		private string Latitude;
		private string Longitude;
		private string Elevation;
		private string Time_Stamp;
		private string Air_Temperature;
		private string Heat_Index;
		private string Station_Pressure;
		private string Surface_Pressure;
		private string Relative_Humidity;
		private string Precipitation;
		private string Precipitation_Accumulation_Last_1hr;
		private string Wind_Average;
		private string Wind_Direction;
		private string Wind_Gust;
		private string Wind_Lull;
		private string Solar_Radiation;
		private string UV;
		private string Illuminance;
		private string Lightening_Strike_Count;
		private string Lightening_Strike_Count_Last_3hr;
		private string Lightening_Strike_Last_Distance;
		private string Lightening_Strike_Avg_Distance;
		private string Air_Battery_Voltage;
		private string Sky_Battery_Voltage;
		private string Tempest_Battery_Voltage;
		private string Precipitation_Accumulation_Local_Day;
		private string Precipitation_Accumulation_Local_Yesterday;
		private string Precipitation_Minutes_Local_Day;
		private string Precipitation_Minutes_Local_Yesterday;
		private string Precipitation_Type;

		private ushort Station_Name_Valid;
		private ushort Latitude_Valid;
		private ushort Longitude_Valid;
		private ushort Elevation_Valid;
		private ushort Time_Stamp_Valid;
		private ushort Air_Temperature_Valid;
		private ushort Heat_Index_Valid;
		private ushort Station_Pressure_Valid;
		private ushort Surface_Pressure_Valid;
		private ushort Relative_Humidity_Valid;
		private ushort Precipitation_Valid;
		private ushort Precipitation_Accumulation_Last_1hr_Valid;
		private ushort Wind_Average_Valid;
		private ushort Wind_Direction_Valid;
		private ushort Wind_Gust_Valid;
		private ushort Wind_Lull_Valid;
		private ushort Solar_Radiation_Valid;
		private ushort UV_Valid;
		private ushort Illuminance_Valid;
		private ushort Lightening_Strike_Count_Valid;
		private ushort Lightening_Strike_Count_Last_3hr_Valid;
		private ushort Lightening_Strike_Last_Distance_Valid;
		private ushort Lightening_Strike_Avg_Distance_Valid;
		private ushort Air_Battery_Voltage_Valid;
		private ushort Sky_Battery_Voltage_Valid;
		private ushort Tempest_Battery_Voltage_Valid;
		private ushort Precipitation_Accumulation_Local_Day_Valid;
		private ushort Precipitation_Accumulation_Local_Yesterday_Valid;
		private ushort Precipitation_Minutes_Local_Day_Valid;
		private ushort Precipitation_Minutes_Local_Yesterday_Valid;
		private ushort Precipitation_Type_Valid;

		private short Air_Temperature_Value;
		private short Heat_Index_Value;
		private short Station_Pressure_Value;
		private short Surface_Pressure_Value;
		private short Relative_Humidity_Value;
		private short Precipitation_Value;
		private short Precipitation_Accumulation_Last_1hr_Value;
		private short Wind_Average_Value;
		private short Wind_Direction_Value;
		private short Wind_Gust_Value;
		private short Wind_Lull_Value;
		private short Solar_Radiation_Value;
		private short UV_Value;
		private short Illuminance_Value;
		private short Lightening_Strike_Count_Value;
		private short Lightening_Strike_Count_Last_3hr_Value;
		private short Lightening_Strike_Last_Distance_Value;
		private short Lightening_Strike_Avg_Distance_Value;
		private short Air_Battery_Voltage_Value;
		private short Sky_Battery_Voltage_Value;
		private short Tempest_Battery_Voltage_Value;
		private short Precipitation_Accumulation_Local_Day_Value;
		private short Precipitation_Accumulation_Local_Yesterday_Value;
		private short Precipitation_Minutes_Local_Day_Value;
		private short Precipitation_Minutes_Local_Yesterday_Value;
		private short Precipitation_Type_Value;

		private string Units_Temp;
		private string Units_Wind;
		private string Units_Precip;
		private string Units_Pressure;
		private string Units_Distance;

		//UDP
		private static UDPServer UDP_Server;
		public static UDP_Display_Formats UDP_Display_Format;
		public string WeatherFlow_Hub_IP;
		private const int WeatherFlow_UDP_Port = 50222;
		#endregion

		//****************************************************************************************
		// 
		//  Initialization	-	Called from s+ to start data collection
		// 
		//****************************************************************************************
		public void Initialization(string Station_ID, string API_Key,
			string Air_Device_ID, string Sky_Device_ID, string Tempest_Device_ID, short Debug)
		{
			#region Check for proper configuration
			if (Station_ID == "")
			{
				CrestronConsole.PrintLine("Missing Station_ID for WeatherFlow Initialization");
				Crestron.SimplSharp.ErrorLog.Error("Missing Station_ID for WeatherFlow Initialization");
				return;
			}

			if (API_Key == "")
			{
				CrestronConsole.PrintLine("Missing Key for WeatherFlow Initialization");
				Crestron.SimplSharp.ErrorLog.Error("Missing Key for WeatherFlow Initialization");
				return;
			}

			if (callback_fn == null)
			{
				CrestronConsole.PrintLine("WeatherFlow-ERROR: Callback Function is NULL");
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow-ERROR: Callback Function is NULL");
				return;
			}
			#endregion

			#region Save Parameters to globals
			this.Station_ID = Station_ID;
			this.API_Key = API_Key;
			this.Air_Device_ID = Air_Device_ID;
			this.Sky_Device_ID = Sky_Device_ID;
			this.Tempest_Device_ID = Tempest_Device_ID;
			#endregion

			Set_Debug_Message_Output(Debug);

			#region Start Timer to Get Data Every 30 Minutes
			if (cTimer == null)
			{
				try
				{
					CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Main_Timer_Thread);
					cTimer = new CTimer(Main_Timer_Thread, this, 0, delay_between_calculations);
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("WeatherFlow-Can't create timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("WeatherFlow-Can't create timer thread: " + e + "\n"));
					return;
				}
			}
			else
			{
				try
				{
					//restart timer that was previously stopped
					cTimer.Reset(0, delay_between_calculations);
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("WeatherFlow-Can't restart timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("WeatherFlow-Can't restart timer thread: " + e + "\n"));
					return;
				}
			}
			#endregion

		}

		//****************************************************************************************
		// 
		//  UDP_Initialization	-	Called from s+ to start data collection through
		//							UPD Messages from Station
		// 
		//****************************************************************************************
		public void UDP_Initialization(string WeatherFlow_Hub_IP, int Display_Format, short Debug)
		{
			#region Save Paramters
			this.WeatherFlow_Hub_IP = WeatherFlow_Hub_IP;
			if (Display_Format == 0)
			{
				UDP_Display_Format = UDP_Display_Formats.English;
			}
			else if (Display_Format == 1)
			{
				UDP_Display_Format = UDP_Display_Formats.Metric;
			}
			else
			{
				UDP_Display_Format = UDP_Display_Formats.English;
			}
			#endregion

			Set_Debug_Message_Output(Debug);

			Start_UDP_Receiver(WeatherFlow_Hub_IP, WeatherFlow_UDP_Port);
		}

		//****************************************************************************************
		// 
		//  Start_UDP_Receiver	-	Startup Receiver to receive UDP Messages
		// 
		//****************************************************************************************
		private void Start_UDP_Receiver(string Bond_IP, int UDP_Port)
		{
			try
			{
				UDP_Server = new UDPServer(IPAddress.Any, UDP_Port, 20000);
				UDP_Server.EnableUDPServer();
				UDP_Server.ReceiveDataAsync(UDP_Receiver_Packet_Received);
			}
			catch (Exception ex)
			{
				string err = "WeatherFlow - Start_UDP_Receiver - Error Starting UDP Receiver: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
		}

		//****************************************************************************************
		// 
		//  UDP_Receiver_Packet_Received	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private void UDP_Receiver_Packet_Received(UDPServer my_UDP_Server, int Byte_Count)
		{
			try
			{
				Debug_Message("UDP_Receiver_Packet_Received", "Number of Bytes Received: " + Byte_Count + ", From: " + my_UDP_Server.IPAddressLastMessageReceivedFrom);

				Byte[] data = (new List<byte>(my_UDP_Server.IncomingDataBuffer)).ToArray();
				String str = System.Text.Encoding.ASCII.GetString(data, 0, Byte_Count);

				#region Parse message if from Bond Bridge or a Sidekick
				if (my_UDP_Server.IPAddressLastMessageReceivedFrom == "10.10.0.24")//TESTER

				{

					Debug_Message("UDP_Receiver_Packet_Received", "Data: " + str);

					UDP_Message message = UDP_Message.Parse(str);

					callback_fn4(message.Event_Time.ToString(),
						Convert.ToUInt16(message.Lightening_Distance),
						Convert.ToUInt16(message.Lightening_Energy),
						Convert.ToUInt16(message.Wind_Speed),
						Convert.ToUInt16(message.Wind_Direction),
						Convert.ToUInt16(message.Wind_Lull),
						Convert.ToUInt16(message.Wind_Avg),
						Convert.ToUInt16(message.Wind_Gust),
						Convert.ToUInt16(message.Station_Pressure),
						Convert.ToInt16(message.Air_Temperature),
						Convert.ToUInt16(message.Relative_Humidity),
						Convert.ToUInt16(message.Illuminance),
						Convert.ToUInt16(message.UV),
						Convert.ToUInt16(message.Solar_Radiation),
						Convert.ToUInt16(message.Precip_Accumulated),
						Convert.ToUInt16(message.Precip_Type),
						Convert.ToUInt16(message.Lightening_Strike_Avg_Distance),
						Convert.ToUInt16(message.Lightening_Strike_Count),
						Convert.ToUInt16(message.Battery),
						Convert.ToUInt16((message.Raining == true)? 1 : 0),
						message.Wind_Speed_Units,
						message.Pressure_Units,
						message.Precip_Units,
						message.Distance_Units,
						message.Illuminance_Units);
				}
				#endregion
			}
			catch (Exception ex)
			{
				string err = "WeatherFlow - UDP_Receiver_Packet_Received - Error Retreiving BPUP_Message: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("WeatherFlow - UDP_Receiver_Packet_Received - \n" + ex.StackTrace);
			}

			my_UDP_Server.ReceiveDataAsync(UDP_Receiver_Packet_Received);
		}

		//****************************************************************************************
		// 
		//  Main_Timer_Thread	-	
		// 
		//****************************************************************************************
		private void Main_Timer_Thread(Object unused)
		{
			string url, s;
			HttpsClientResponse httpsResponse;

			#region get WeatherFlow datapoint data
			try
			{
				Init_Data_Elements();

				url = "https://swd.weatherflow.com/swd/rest/observations/station/" + Station_ID + "?api_key=" + API_Key;
				httpsResponse = Send_Message_Get(url);
				if (httpsResponse == null)
				{
					Debug_Message("Main_Timer_Thread", "WeatherFlow-Response-Observations = null");
					return;
				}
				s = httpsResponse.ContentString;
				Debug_Message("Main_Timer_Thread", "WeatherFlow-Response-Observations = " + s);//tester
				Parse_Observation_Data(s);

				if (int.Parse(Air_Device_ID) != 0)
				{
					url = "https://swd.weatherflow.com/swd/rest/observations/device/" + Air_Device_ID + "?api_key=" + API_Key;
					httpsResponse = Send_Message_Get(url);
					if (httpsResponse == null)
					{
						Debug_Message("Main_Timer_Thread", "WeatherFlow-Response-Air = null");
						return;
					}
					s = httpsResponse.ContentString;
					Parse_Air_Data(s);
				}

				if (int.Parse(Sky_Device_ID) != 0)
				{
					url = "https://swd.weatherflow.com/swd/rest/observations/device/" + Sky_Device_ID + "?api_key=" + API_Key;
					httpsResponse = Send_Message_Get(url);
					if (httpsResponse == null)
					{
						Debug_Message("Main_Timer_Thread", "WeatherFlow-Response-Sky = null");
						return;
					}
					s = httpsResponse.ContentString;
					Parse_Sky_Data(s);
				}

				if (int.Parse(Tempest_Device_ID) != 0)
				{
					url = "https://swd.weatherflow.com/swd/rest/observations/device/" + Tempest_Device_ID + "?api_key=" + API_Key;
					httpsResponse = Send_Message_Get(url);
					if (httpsResponse == null)
					{
						Debug_Message("Main_Timer_Thread", "WeatherFlow-Response-Tempest = null");
						return;
					}
					s = httpsResponse.ContentString;
					Parse_Tempest_Data(s);
				}

				//Send Data Back to Simpl
				callback_fn(Station_Name, Station_Name_Valid,
					Latitude, Latitude_Valid,
					Longitude, Longitude_Valid,
					Elevation, Elevation_Valid,
					Time_Stamp, Time_Stamp_Valid,
					Air_Temperature, Air_Temperature_Value, Air_Temperature_Valid,
					Air_Temperature, Air_Temperature_Value, Air_Temperature_Valid,
					Station_Pressure, Station_Pressure_Value, Station_Pressure_Valid,
					Surface_Pressure, Surface_Pressure_Value, Surface_Pressure_Valid,
					Relative_Humidity, Relative_Humidity_Value, Relative_Humidity_Valid,
					Precipitation, Precipitation_Value, Precipitation_Valid,
					Precipitation_Accumulation_Last_1hr, Precipitation_Accumulation_Last_1hr_Value, Precipitation_Accumulation_Last_1hr_Valid,
					Wind_Average, Wind_Average_Value, Wind_Average_Valid,
					Wind_Direction, Wind_Direction_Value, Wind_Direction_Valid,
					Wind_Gust, Wind_Gust_Value, Wind_Gust_Valid,
					Wind_Lull, Wind_Lull_Value, Wind_Lull_Valid,
					Solar_Radiation, Solar_Radiation_Value, Solar_Radiation_Valid,
					UV, UV_Value, UV_Valid,
					Lightening_Strike_Count, Lightening_Strike_Count_Value, Lightening_Strike_Count_Valid,
					Lightening_Strike_Count_Last_3hr, Lightening_Strike_Count_Last_3hr_Value, Lightening_Strike_Count_Last_3hr_Valid,
					Lightening_Strike_Last_Distance, Lightening_Strike_Last_Distance_Value, Lightening_Strike_Last_Distance_Valid,
					Sky_Battery_Voltage, Sky_Battery_Voltage_Value, Sky_Battery_Voltage_Valid,
					Air_Battery_Voltage, Air_Battery_Voltage_Value, Air_Battery_Voltage_Valid,
					Tempest_Battery_Voltage, Tempest_Battery_Voltage_Value, Tempest_Battery_Voltage_Valid,
					Precipitation_Accumulation_Local_Day, Precipitation_Accumulation_Local_Day_Value, Precipitation_Accumulation_Local_Day_Valid,
					Precipitation_Accumulation_Local_Yesterday, Precipitation_Accumulation_Local_Yesterday_Value, Precipitation_Accumulation_Local_Yesterday_Valid,
					Precipitation_Minutes_Local_Day, Precipitation_Minutes_Local_Day_Value, Precipitation_Minutes_Local_Day_Valid,
					Precipitation_Minutes_Local_Yesterday, Precipitation_Minutes_Local_Yesterday_Value, Precipitation_Minutes_Local_Yesterday_Valid,
					Lightening_Strike_Avg_Distance, Lightening_Strike_Avg_Distance_Value, Lightening_Strike_Avg_Distance_Valid,
					Illuminance, Illuminance_Value, Illuminance_Valid,
					Precipitation_Type, Precipitation_Type_Value, Precipitation_Type_Valid);
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("WeatherFlow-Error Obtaining WeatherFlow Datapoints");
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow-Error Obtaining WeatherFlow Datapoints");
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Observation_Data	-	Parse all data from message
		// 
		//****************************************************************************************
		private void Parse_Observation_Data(string s)
		{
			int index = 0;
			ushort dummy = 0;

			Debug_Message("Parse_Observation_Data", "s = " + s);

			#region Parse Station Info
			Station_Name = Parse_Data_Substring(s, "\"station_name\"", ":\"", "\",", index, ref Station_Name_Valid);

			Latitude = Parse_Data_Substring(s, "\"latitude\"", ":", ",", index, ref Latitude_Valid);
			Longitude = Parse_Data_Substring(s, "\"longitude\"", ":", ",", index, ref Longitude_Valid);
			Elevation = Parse_Data_Substring(s, "\"elevation\"", ":", ",", index, ref Elevation_Valid);
			#endregion

			#region Get Index to Station Units
			//get index to start of value
			index = s.IndexOf("\"station_units\":{", 0);
			if (index == -1)
			{
				CrestronConsole.PrintLine("WeatherFlow-Unable to Locate \"station_units\" in " + s);
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow-Unable to Locate \"station_units\" in " + s);
				return;
			}
			#endregion

			#region Parse Station Units
			Units_Temp = Parse_Data_Substring(s, "\"units_temp\"", ":\"", "\",", index, ref dummy);
			Units_Wind = Parse_Data_Substring(s, "\"units_wind\"", ":\"", "\",", index, ref dummy);
			Units_Precip = Parse_Data_Substring(s, "\"units_precip\"", ":\"", "\",", index, ref dummy);
			Units_Pressure = Parse_Data_Substring(s, "\"units_pressure\"", ":\"", "\",", index, ref dummy);
			Units_Distance = Parse_Data_Substring(s, "\"units_distance\"", ":\"", "\",", index, ref dummy);
			#endregion

			#region Get Index to Observation Data
			//get index to start of value
			index = s.IndexOf("\"obs\":[", 0);
			if (index == -1)
			{
				CrestronConsole.PrintLine("WeatherFlow-Unable to Locate \"obs\" in " + s);
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow-Unable to Locate \"obs\" in " + s);
				return;
			}
			#endregion

			#region Parse Observation Data
			Time_Stamp = Parse_Data_Substring(s, "\"timestamp\"", ":", ",", index, ref Time_Stamp_Valid);
			Air_Temperature = Parse_Data_Substring(s, "\"air_temperature\"", ":", ",", index, ref Air_Temperature_Valid);
			Heat_Index = Parse_Data_Substring(s, "\"heat_index\"", ":", ",", index, ref Heat_Index_Valid);
			Station_Pressure = Parse_Data_Substring(s, "\"barometric_pressure\"", ":", ",", index, ref Station_Pressure_Valid);
			Relative_Humidity = Parse_Data_Substring(s, "\"relative_humidity\"", ":", ",", index, ref Relative_Humidity_Valid);
			Precipitation = Parse_Data_Substring(s, "\"precip\"", ":", ",", index, ref Precipitation_Valid);
			Precipitation_Accumulation_Last_1hr = Parse_Data_Substring(s, "\"precip_accum_last_1hr\"", ":", ",", index, ref Precipitation_Accumulation_Last_1hr_Valid);
			Wind_Average = Parse_Data_Substring(s, "\"wind_avg\"", ":", ",", index, ref Wind_Average_Valid);
			Wind_Direction = Parse_Data_Substring(s, "\"wind_direction\"", ":", ",", index, ref Wind_Direction_Valid);
			Wind_Gust = Parse_Data_Substring(s, "\"wind_gust\"", ":", ",", index, ref Wind_Gust_Valid);
			Wind_Lull = Parse_Data_Substring(s, "\"wind_lull\"", ":", ",", index, ref Wind_Lull_Valid);
			Solar_Radiation = Parse_Data_Substring(s, "\"solar_radiation\"", ":", ",", index, ref Solar_Radiation_Valid);
			UV = Parse_Data_Substring(s, "\"uv\"", ":", ",", index, ref UV_Valid);
			Lightening_Strike_Count = Parse_Data_Substring(s, "\"lightning_strike_count\"", ":", ",", index, ref Lightening_Strike_Count_Valid);
			Lightening_Strike_Count_Last_3hr = Parse_Data_Substring(s, "\"lightning_strike_count_last_3hr\"", ":", ",", index, ref Lightening_Strike_Count_Last_3hr_Valid);
			Lightening_Strike_Last_Distance = Parse_Data_Substring(s, "\"lightning_strike_last_distance\"", ":", ",", index, ref Lightening_Strike_Last_Distance_Valid);
			Precipitation_Accumulation_Local_Day = Parse_Data_Substring(s, "\"precip_accum_local_day\"", ":", ",", index, ref Precipitation_Accumulation_Local_Day_Valid);
			Precipitation_Accumulation_Local_Yesterday = Parse_Data_Substring(s, "\"precip_accum_local_yesterday\"", ":", ",", index, ref Precipitation_Accumulation_Local_Yesterday_Valid);
			Precipitation_Minutes_Local_Day = Parse_Data_Substring(s, "\"precip_minutes_local_day\"", ":", ",", index, ref Precipitation_Minutes_Local_Day_Valid);
			Precipitation_Minutes_Local_Yesterday = Parse_Data_Substring(s, "\"precip_minutes_local_yesterday\"", ":", ",", index, ref Precipitation_Minutes_Local_Yesterday_Valid);

			#endregion

			#region Calculate Surface Pressure
			//https://keisan.casio.com/exec/system/1224575267
			if ((Station_Pressure_Valid == 1) && (Elevation_Valid == 1) & (Air_Temperature_Valid == 1))
			{
				double atmospheric_pressure = String_To_Scaled_Short(Station_Pressure, 1);
				double altitude = String_To_Scaled_Short(Elevation, 1);
				short temperature = String_To_Scaled_Short(Air_Temperature, 1);
				double temp = atmospheric_pressure * Math.Pow((1 - ((.0065 * altitude) / (temperature + (.0065 * altitude) + 273.15))), -5.257);
				Surface_Pressure_Valid = 1;
				Surface_Pressure = Convert.ToInt16(temp).ToString();
			}
			#endregion

			Convert_Data_To_Station_Unit_Format();

			String_Data_To_Analogs();

			#region Wind Direction to Cardinal
			if (Wind_Direction_Valid == 1)
			{
				Wind_Direction = Degrees_To_Cardinal_Direction(Wind_Direction_Value);
			}
			#endregion

			#region Convert Timestamp to Local Date/Time
			if (Time_Stamp_Valid == 1)
			{
				DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0);
				dateTime = dateTime.AddSeconds(Convert.ToDouble(Time_Stamp));
				dateTime = dateTime.ToLocalTime();
				Time_Stamp = dateTime.ToString();
			}
			#endregion

			#region Add Units to Observations
			if (Air_Temperature_Valid == 1)
			{
				Air_Temperature += Convert.ToChar(176).ToString() + Units_Temp.ToUpper();
			}

			if (Station_Pressure_Valid == 1)
			{
				Station_Pressure += " " + Units_Pressure;
			}

			if (Surface_Pressure_Valid == 1)
			{
				Surface_Pressure += " " + Units_Pressure;
			}

			if (Relative_Humidity_Valid == 1)
			{
				Relative_Humidity += "%";
			}

			if (Precipitation_Valid == 1)
			{
				Precipitation += " " + Units_Precip;
			}

			if (Precipitation_Accumulation_Last_1hr_Valid == 1)
			{
				Precipitation_Accumulation_Last_1hr += " " + Units_Precip;
			}

			if (Wind_Average_Valid == 1)
			{
				Wind_Average += " " + Units_Wind;
			}

			if (Wind_Gust_Valid == 1)
			{
				Wind_Gust += " " + Units_Wind;
			}

			if (Wind_Lull_Valid == 1)
			{
				Wind_Lull += " " + Units_Wind;
			}

			if (Lightening_Strike_Last_Distance_Valid == 1)
			{
				Lightening_Strike_Last_Distance += " " + Units_Distance;
			}

			if (Precipitation_Accumulation_Local_Day_Valid == 1)
			{
				Precipitation_Accumulation_Local_Day += " " + Units_Precip;
			}

			if (Precipitation_Accumulation_Local_Yesterday_Valid == 1)
			{
				Precipitation_Accumulation_Local_Yesterday += " " + Units_Precip;
			}

			if (Precipitation_Minutes_Local_Day_Valid == 1)
			{
				if (Precipitation_Minutes_Local_Day_Value == 1)
				{
					Precipitation_Minutes_Local_Day += " Minute";
				}
				else
				{
					Precipitation_Minutes_Local_Day += " Minutes";
				}
			}

			if (Precipitation_Minutes_Local_Yesterday_Valid == 1)
			{
				if (Precipitation_Minutes_Local_Yesterday_Value == 1)
				{
					Precipitation_Minutes_Local_Yesterday += " Minute";
				}
				else
				{
					Precipitation_Minutes_Local_Yesterday += " Minutes";
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Air_Data	-	Parse all data from message
		// 
		//****************************************************************************************
		private void Parse_Air_Data(string s)
		{
			int index1;
			ushort valid = 0;
			string substring;
			double d;
			string[] csv = new string[20];

			Debug_Message("Parse_Air_Data", "s = " + s);

			#region Validate that valid data returned
			index1 = s.IndexOf("SUCCESS", 0);
			if (index1 == -1)
			{
				Debug_Message("Parse_Air_Data", "WeatherFlow-Parse_Air_Data - Unsuccessful Data Returned from Get" + s);
				return;
			}
			#endregion

			#region get comma separated values
			substring = Parse_Data_Substring(s, "", "\"obs\":[[", "]]", 0, ref valid);
			if (valid == 0)
			{
				Debug_Message("Parse_Air_Data", "WeatherFlow-Parse_Air_Data - Unable to parse data substring" + s);
				return;
			}
			//split into array of elements
			csv = substring.Split(',');
			#endregion

			#region Battery Voltage
			Air_Battery_Voltage = csv[6];
			d = double.Parse(Air_Battery_Voltage);
			d *= 100;															//10ths of volts
			Air_Battery_Voltage_Value = Convert.ToInt16(d);
			Air_Battery_Voltage_Valid = 1;
			Air_Battery_Voltage += " volts";
			#endregion

			#region Lightening Strike Average Distance
			Lightening_Strike_Avg_Distance = csv[5];
			Lightening_Strike_Avg_Distance_Valid = 1;
			d = double.Parse(Lightening_Strike_Avg_Distance);
			if (Units_Distance == "mi")
			{
				d /= 1.609;
				d = Math.Round(d, 4);
				Lightening_Strike_Avg_Distance_Value = Convert.ToInt16(d);
				Lightening_Strike_Avg_Distance = d.ToString();
			}
			Lightening_Strike_Avg_Distance += (" " + Units_Distance);
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Sky_Data	-	Parse all data from message
		// 
		//****************************************************************************************
		private void Parse_Sky_Data(string s)
		{
			int index1;
			ushort valid = 0;
			string substring;
			double d;
			string[] csv = new string[20];

			Debug_Message("Parse_Sky_Data", "s = " + s);

			#region Validate that valid data returned
			index1 = s.IndexOf("SUCCESS", 0);
			if (index1 == -1)
			{
				Debug_Message("Parse_Sky_Data", "WeatherFlow-Parse_Sky_Data - Unsuccessful Data Returned from Get" + s);
				return;
			}
			#endregion

			#region get comma separated values
			substring = Parse_Data_Substring(s, "", "\"obs\":[[", "]]", 0, ref valid);
			if (valid == 0)
			{
				Debug_Message("Parse_Sky_Data", "WeatherFlow-Parse_Sky_Data - Unable to parse data substring" + s);
				return;
			}
			//split into array of elements
			csv = substring.Split(',');
			#endregion

			#region Battery Voltage
			Sky_Battery_Voltage = csv[8];
			d = double.Parse(Sky_Battery_Voltage);
			d *= 100;															//10ths of volts
			Sky_Battery_Voltage_Value = Convert.ToInt16(d);
			Sky_Battery_Voltage_Valid = 1;
			Sky_Battery_Voltage += " volts";
			#endregion

			#region Illuminance
			Illuminance = csv[1];
			d = double.Parse(Illuminance);
			if (d > 30000)				//avoid int16 data overflow
			{
				d /= 1000;
				d = Math.Round(d, 0);
				Illuminance = d.ToString();
				Illuminance += " kilolux";
			}
			else
			{
				Illuminance += " lux";
			}
			Illuminance_Value = Convert.ToInt16(d);
			Illuminance_Valid = 1;
			#endregion

			#region Precipitation Type
			Precipitation_Type_Value = short.Parse(csv[12]);
			Precipitation_Type_Valid = 1;
			switch (Precipitation_Type_Value)
			{
				case 0:
					Precipitation_Type = "None";
					break;

				case 1:
					Precipitation_Type = "Rain";
					break;

				case 2:
					Precipitation_Type = "Hail";
					break;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Tempest_Data	-	Parse all data from message
		// 
		//****************************************************************************************
		private void Parse_Tempest_Data(string s)
		{
			int index1;
			ushort valid = 0;
			string substring;
			double d;
			string[] csv = new string[20];

			Debug_Message("Parse_Tempest_Data", "s = " + s);

			#region Validate that valid data returned
			index1 = s.IndexOf("SUCCESS", 0);
			if (index1 == -1)
			{
				Debug_Message("Parse_Tempest_Data", "WeatherFlow-Parse_Tempest_Data - Unsuccessful Data Returned from Get" + s);
				return;
			}
			#endregion

			#region get comma separated values
			substring = Parse_Data_Substring(s, "", "\"obs\":[[", "]]", 0, ref valid);
			if (valid == 0)
			{
				Debug_Message("Parse_Tempest_Data", "WeatherFlow-Parse_Tempest_Data - Unable to parse data substring" + s);
				return;
			}
			else
			{
				Debug_Message("Parse_Tempest_Data", "s = " + s);
			}

			//split into array of elements
			csv = substring.Split(',');

			for (int i = 0; i < 20; i++)
			{
				Debug_Message("Parse_Tempest_Data", "csv[" + i + "] = " + csv[i]);
			}
			#endregion

			#region Battery Voltage
			Tempest_Battery_Voltage = csv[16];
			Debug_Message("Parse_Tempest_Data", "Tempest_Battery_Voltage = " + Tempest_Battery_Voltage);
			try
			{
				d = double.Parse(Tempest_Battery_Voltage);
				d *= 100;															//10ths of volts
				Tempest_Battery_Voltage_Value = Convert.ToInt16(d);
				Tempest_Battery_Voltage_Valid = 1;
				Tempest_Battery_Voltage += " volts";
			}
			catch (Exception ex)
			{
				Debug_Message("Parse_Tempest_Data", "Parse Battery Voltage Exception:" + ex);
				Tempest_Battery_Voltage = string.Empty;
				Tempest_Battery_Voltage_Value = 0;
				Tempest_Battery_Voltage_Valid = 0;
			}
			#endregion

			#region Lightening Strike Average Distance
			Lightening_Strike_Avg_Distance = csv[14];
			Debug_Message("Parse_Tempest_Data", "Lightening_Strike_Avg_Distance = " + Lightening_Strike_Avg_Distance);
			try
			{
				d = double.Parse(Lightening_Strike_Avg_Distance);
				Lightening_Strike_Avg_Distance_Valid = 1;
				if (Units_Distance == "mi")
				{
					d /= 1.609;
					d = Math.Round(d, 4);
					Lightening_Strike_Avg_Distance_Value = Convert.ToInt16(d);
					Lightening_Strike_Avg_Distance = d.ToString();
				}
				Lightening_Strike_Avg_Distance += (" " + Units_Distance);
			}
			catch (Exception ex)
			{
				Debug_Message("Parse_Tempest_Data", "Parse Lightening Strike Average Distance Exception:" + ex);
				Lightening_Strike_Avg_Distance = string.Empty;
				Lightening_Strike_Avg_Distance_Value = 0;
				Lightening_Strike_Avg_Distance_Valid = 0;
			}
			#endregion

			#region Illuminance
			Illuminance = csv[9];
			Debug_Message("Parse_Tempest_Data", "Illuminance = " + Illuminance);
			try
			{
				d = double.Parse(Illuminance);
				if (d > 30000)				//avoid int16 data overflow
				{
					d /= 1000;
					d = Math.Round(d, 0);
					Illuminance = d.ToString();
					Illuminance += " kilolux";
				}
				else
				{
					Illuminance += " lux";
				}
				Illuminance_Value = Convert.ToInt16(d);
				Illuminance_Valid = 1;
			}
			catch (Exception ex)
			{
				Debug_Message("Parse_Tempest_Data", "Parse Illuminance Exception:" + ex);
				Illuminance = string.Empty;
				Illuminance_Value = 0;
				Illuminance_Valid = 0;
			}
			#endregion

			#region Precipitation Type
			try
			{
				Precipitation_Type_Value = short.Parse(csv[13]);
				Debug_Message("Parse_Tempest_Data", "Precipitation_Type_Value = " + Precipitation_Type_Value);
				Precipitation_Type_Valid = 1;
				switch (Precipitation_Type_Value)
				{
					case 0:
						Precipitation_Type = "None";
						break;

					case 1:
						Precipitation_Type = "Rain";
						break;

					case 2:
						Precipitation_Type = "Hail";
						break;
				}
			}
			catch (Exception ex)
			{
				Debug_Message("Parse_Tempest_Data", "Parse Parcipitation Type Exception:" + ex);
				Precipitation_Type = string.Empty;
				Precipitation_Type_Value = 0;
				Precipitation_Type_Valid = 0;
			}
			#endregion

		}

		//****************************************************************************************
		// 
		//  Convert_Data_To_Station_Unit_Format	-	Convert weather data based on Station Units
		// 
		//****************************************************************************************
		private void Convert_Data_To_Station_Unit_Format()
		{
			double temp;

			//convert Air_Temperature from Celcius to Fahrenheit
			if (Units_Temp == "f")
			{
				if (Air_Temperature_Valid == 1)
				{
					temp = Convert.ToDouble(Air_Temperature);
					temp = (temp * 1.8) + 32;
					temp = Math.Round(temp, 4);
					Air_Temperature = temp.ToString();
				}

				if (Heat_Index_Valid == 1)
				{
					temp = Convert.ToDouble(Heat_Index);
					temp = (temp * 1.8) + 32;
					temp = Math.Round(temp, 4);
					Heat_Index = temp.ToString();
				}
			}

			// Convert Pressure from mbar to inhg
			if (Units_Pressure == "inhg")
			{
				if (Station_Pressure_Valid == 1)
				{
					temp = Convert.ToDouble(Station_Pressure);
					temp /= 33.864;
					temp = Math.Round(temp, 4);
					Station_Pressure = temp.ToString();
				}

				if (Surface_Pressure_Valid == 1)
				{
					temp = Convert.ToDouble(Surface_Pressure);
					temp /= 33.864;
					temp = Math.Round(temp, 4);
					Surface_Pressure = temp.ToString();
				}
			}

			// Convert Precipitation from mm to inches
			if (Units_Precip == "in")
			{
				if (Precipitation_Valid == 1)
				{
					temp = Convert.ToDouble(Precipitation);
					temp /= 25.4;
					temp = Math.Round(temp, 4);
					Precipitation = temp.ToString();
				}

				if (Precipitation_Accumulation_Last_1hr_Valid == 1)
				{
					temp = Convert.ToDouble(Precipitation_Accumulation_Last_1hr);
					temp /= 25.4;
					temp = Math.Round(temp, 4);
					Precipitation_Accumulation_Last_1hr = temp.ToString();
				}

				if (Precipitation_Accumulation_Local_Day_Valid == 1)
				{
					temp = Convert.ToDouble(Precipitation_Accumulation_Local_Day);
					temp /= 25.4;
					temp = Math.Round(temp, 4);
					Precipitation_Accumulation_Local_Day = temp.ToString();
				}

				if (Precipitation_Accumulation_Local_Yesterday_Valid == 1)
				{
					temp = Convert.ToDouble(Precipitation_Accumulation_Local_Yesterday);
					temp /= 25.4;
					temp = Math.Round(temp, 4);
					Precipitation_Accumulation_Local_Yesterday = temp.ToString();
				}
			}

			// Convert Wind from Meters/Second to MPH
			if (Units_Wind == "mph")
			{
				if (Wind_Average_Valid == 1)
				{
					temp = Convert.ToDouble(Wind_Average);
					temp *= 2.237;
					temp = Math.Round(temp, 4);
					Wind_Average = temp.ToString();
				}

				if (Wind_Gust_Valid == 1)
				{
					temp = Convert.ToDouble(Wind_Gust);
					temp *= 2.237;
					temp = Math.Round(temp, 4);
					Wind_Gust = temp.ToString();
				}

				if (Wind_Lull_Valid == 1)
				{
					temp = Convert.ToDouble(Wind_Lull);
					temp *= 2.237;
					temp = Math.Round(temp, 4);
					Wind_Lull = temp.ToString();
				}
			}

			// Convert Lightening Distance from Km to Miles
			if (Units_Distance == "mi")
			{
				if (Lightening_Strike_Last_Distance_Valid == 1)
				{
					temp = Convert.ToDouble(Lightening_Strike_Last_Distance);
					temp /= 1.609;
					temp = Math.Round(temp, 4);
					Lightening_Strike_Last_Distance = temp.ToString();
				}
			}
		}

		//****************************************************************************************
		// 
		//  String_Data_To_Analogs	-	Convert weather data to analogs and scale for use in simpl
		// 
		//****************************************************************************************
		private void String_Data_To_Analogs()
		{
			if (Air_Temperature_Valid == 1)
			{
				Air_Temperature_Value = String_To_Scaled_Short(Air_Temperature, 100);
			}

			if (Heat_Index_Valid == 1)
			{
				Heat_Index_Value = String_To_Scaled_Short(Heat_Index, 100);
			}

			if (Station_Pressure_Valid == 1)
			{
				Station_Pressure_Value = String_To_Scaled_Short(Station_Pressure, 1);
			}

			if (Surface_Pressure_Valid == 1)
			{
				Surface_Pressure_Value = String_To_Scaled_Short(Surface_Pressure, 1);
			}

			if (Relative_Humidity_Valid == 1)
			{
				Relative_Humidity_Value = String_To_Scaled_Short(Relative_Humidity, 1);
			}

			if (Precipitation_Valid == 1)
			{
				Precipitation_Value = String_To_Scaled_Short(Precipitation, 100);
			}

			if (Precipitation_Accumulation_Last_1hr_Valid == 1)
			{
				Precipitation_Accumulation_Last_1hr_Value = String_To_Scaled_Short(Precipitation_Accumulation_Last_1hr, 100);
			}

			if (Wind_Average_Valid == 1)
			{
				Wind_Average_Value = String_To_Scaled_Short(Wind_Average, 10);
			}

			if (Wind_Direction_Valid == 1)
			{
				Wind_Direction_Value = String_To_Scaled_Short(Wind_Direction, 1);
			}

			if (Wind_Gust_Valid == 1)
			{
				Wind_Gust_Value = String_To_Scaled_Short(Wind_Gust, 10);
			}

			if (Wind_Lull_Valid == 1)
			{
				Wind_Lull_Value = String_To_Scaled_Short(Wind_Lull, 10);
			}

			if (Solar_Radiation_Valid == 1)
			{
				Solar_Radiation_Value = String_To_Scaled_Short(Solar_Radiation, 1);
			}

			if (UV_Valid == 1)
			{
				UV_Value = String_To_Scaled_Short(UV, 1);
			}

			if (Lightening_Strike_Count_Valid == 1)
			{
				Lightening_Strike_Count_Value = String_To_Scaled_Short(Lightening_Strike_Count, 1);
			}

			if (Lightening_Strike_Count_Last_3hr_Valid == 1)
			{
				Lightening_Strike_Count_Last_3hr_Value = String_To_Scaled_Short(Lightening_Strike_Count_Last_3hr, 1);
			}

			if (Lightening_Strike_Last_Distance_Valid == 1)
			{
				Lightening_Strike_Last_Distance_Value = String_To_Scaled_Short(Lightening_Strike_Last_Distance, 1);
			}

			if (Precipitation_Accumulation_Local_Day_Valid == 1)
			{
				Precipitation_Accumulation_Local_Day_Value = String_To_Scaled_Short(Precipitation_Accumulation_Local_Day, 100);
			}

			if (Precipitation_Accumulation_Local_Yesterday_Valid == 1)
			{
				Precipitation_Accumulation_Local_Yesterday_Value = String_To_Scaled_Short(Precipitation_Accumulation_Local_Yesterday, 100);
			}

			if (Precipitation_Minutes_Local_Day_Valid == 1)
			{
				Precipitation_Minutes_Local_Day_Value = String_To_Scaled_Short(Precipitation_Minutes_Local_Day, 1);
			}

			if (Precipitation_Minutes_Local_Yesterday_Valid == 1)
			{
				Precipitation_Minutes_Local_Yesterday_Value = String_To_Scaled_Short(Precipitation_Minutes_Local_Yesterday, 1);
			}		
		}

		//****************************************************************************************
		// 
		//  Degrees_To_Cardinal_Direction	-	Convert from Degrees to Cardinal Direction
		// 
		//****************************************************************************************
		private string Degrees_To_Cardinal_Direction(short degrees)
		{
			if ((degrees >= 348.75) && (degrees < 11.25))
			{
				return "N";
			}
			else if ((degrees >= 11.25) && (degrees < 33.75))
			{
				return "NNE";
			}
			else if ((degrees >= 33.75) && (degrees < 56.25))
			{
				return "NE";
			}
			else if ((degrees >= 56.25) && (degrees < 78.75))
			{
				return "ENE";
			}
			else if ((degrees >= 78.75) && (degrees < 101.25))
			{
				return "E";
			}
			else if ((degrees >= 101.25) && (degrees < 123.75))
			{
				return "ESE";
			}
			else if ((degrees >= 123.75) && (degrees < 146.25))
			{
				return "SE";
			}
			else if ((degrees >= 146.25) && (degrees < 168.75))
			{
				return "SSE";
			}
			else if ((degrees >= 168.75) && (degrees < 191.25))
			{
				return "S";
			}
			else if ((degrees >= 191.25) && (degrees < 213.75))
			{
				return "SSW";
			}
			else if ((degrees >= 213.75) && (degrees < 236.25))
			{
				return "SW";
			}
			else if ((degrees >= 236.25) && (degrees < 258.75))
			{
				return "WSW";
			}
			else if ((degrees >= 258.75) && (degrees < 281.25))
			{
				return "W";
			}
			else if ((degrees >= 281.25) && (degrees < 303.75))
			{
				return "WNW";
			}
			else if ((degrees >= 303.75) && (degrees < 326.25))
			{
				return "NW";
			}
			else if ((degrees >= 326.25) && (degrees < 348.75))
			{
				return "NNW";
			}
			else
			{
				return "";
			}

		}

		//****************************************************************************************
		// 
		//  Init_Data_Elements	-	initialize data elements before parsing
		// 
		//****************************************************************************************
		private void Init_Data_Elements()
		{
			Station_Name = "";
			Latitude = "";
			Longitude = "";
			Elevation = "";
			Time_Stamp = "";
			Air_Temperature = "";
			Heat_Index = "";
			Station_Pressure = "";
			Surface_Pressure = "";
			Relative_Humidity = "";
			Precipitation = "";
			Precipitation_Accumulation_Last_1hr = "";
			Wind_Direction = "";
			Wind_Average = "";
			Wind_Gust = "";
			Wind_Lull = "";
			Solar_Radiation = "";
			UV = "";
			Illuminance = "";
			Lightening_Strike_Count = "";
			Lightening_Strike_Count_Last_3hr = "";
			Lightening_Strike_Last_Distance = "";
			Lightening_Strike_Avg_Distance = "";
			Air_Battery_Voltage = "";
			Sky_Battery_Voltage = "";
			Tempest_Battery_Voltage = "";
			Precipitation_Accumulation_Local_Day = "";
			Precipitation_Accumulation_Local_Yesterday = "";
			Precipitation_Minutes_Local_Day = "";
			Precipitation_Minutes_Local_Yesterday = "";
			Precipitation_Type = "";

			Air_Temperature_Value = 0;
			Heat_Index_Value = 0;
			Station_Pressure_Value = 0;
			Surface_Pressure_Value = 0;
			Relative_Humidity_Value = 0;
			Precipitation_Value = 0;
			Precipitation_Accumulation_Last_1hr_Value = 0;
			Wind_Average_Value = 0;
			Wind_Direction_Value = 0;
			Wind_Gust_Value = 0;
			Wind_Lull_Value = 0;
			Solar_Radiation_Value = 0;
			UV_Value = 0;
			Illuminance_Value = 0;
			Lightening_Strike_Count_Value = 0;
			Lightening_Strike_Count_Last_3hr_Value = 0;
			Lightening_Strike_Last_Distance_Value = 0;
			Lightening_Strike_Avg_Distance_Value = 0;
			Air_Battery_Voltage_Value = 0;
			Sky_Battery_Voltage_Value = 0;
			Tempest_Battery_Voltage_Value = 0;
			Precipitation_Accumulation_Local_Day_Value = 0;
			Precipitation_Accumulation_Local_Yesterday_Value = 0;
			Precipitation_Minutes_Local_Day_Value = 0;
			Precipitation_Minutes_Local_Yesterday_Value = 0;
			Precipitation_Type_Value = 0;

			Station_Name_Valid = 0;
			Latitude_Valid = 0;
			Longitude_Valid = 0;
			Elevation_Valid = 0;
			Air_Temperature_Valid = 0;
			Heat_Index_Valid = 0;
			Station_Pressure_Valid = 0;
			Surface_Pressure_Valid = 0;
			Relative_Humidity_Valid = 0;
			Precipitation_Valid = 0;
			Precipitation_Accumulation_Last_1hr_Valid = 0;
			Wind_Average_Valid = 0;
			Wind_Direction_Valid = 0;
			Wind_Gust_Valid = 0;
			Wind_Lull_Valid = 0;
			Solar_Radiation_Valid = 0;
			UV_Valid = 0;
			Illuminance_Valid = 0;
			Lightening_Strike_Count_Valid = 0;
			Lightening_Strike_Count_Last_3hr_Valid = 0;
			Lightening_Strike_Last_Distance_Valid = 0;
			Lightening_Strike_Avg_Distance_Valid = 0;
			Air_Battery_Voltage_Valid = 0;
			Sky_Battery_Voltage_Valid = 0;
			Tempest_Battery_Voltage_Valid = 0;
			Precipitation_Accumulation_Local_Day_Valid = 0;
			Precipitation_Accumulation_Local_Yesterday_Valid = 0;
			Precipitation_Minutes_Local_Day_Valid = 0;
			Precipitation_Minutes_Local_Yesterday_Valid = 0;
			Precipitation_Type_Valid = 0;

			Units_Temp = "";
			Units_Wind = "";
			Units_Precip = "";
			Units_Pressure = "";
			Units_Distance = "";
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string id, string data_starting_chars, string data_ending_chars, int start_index, ref ushort valid)
		{
			int index1, index2;
			string id1 = id + data_starting_chars;

			//get index to start of value
			index1 = s.IndexOf(id1, start_index);
			if (index1 == -1)
			{
				Debug_Message("Parse_Data_Substring", "WeatherFlow-Unable to Locate " + id + " in " + s);
				valid = 0;
				return "";
			}
			else
			{
				index1 += +id1.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(data_ending_chars, (index1 + 1));
			if (index2 == -1)
			{
				Debug_Message("Parse_Data_Substring", "WeatherFlow-Unable to Locate terminating " + data_ending_chars + " for " + id + " in " + s);
				valid = 0;
				return "";
			}

			//set that data element is valid
			valid = 1;

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Send_Message_Get	-	
		// 
		//****************************************************************************************
		private HttpsClientResponse Send_Message_Get(string url)
		{

			// Create the client
			HttpsClient httpsClient = new HttpsClient();

			//turn verification off, to stop it taking a dump on cert errors
			httpsClient.HostVerification = false;
			httpsClient.PeerVerification = false;

			//create the request, populate it
			HttpsClientRequest httpsRequest = new HttpsClientRequest();

			httpsRequest.Url.Parse(url);
			httpsRequest.RequestType = RequestType.Get;

			//attempt to dispatch the request
			try
			{
				return httpsClient.Dispatch(httpsRequest);
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("WeatherFlow-Error Sending Message (0) url = ", url);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow-Error Sending Message (0) url = ", url);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				return null;
			}
			finally
			{
				if (httpsClient != null)
				{
					httpsClient.Dispose();
				}
			}
		}

		//****************************************************************************************
		// 
		//  String_To_Scaled_Short	-	
		// 
		//****************************************************************************************
		short String_To_Scaled_Short(string s, double scaler)
		{
			double temp;

			temp = Convert.ToDouble(s);
			temp = temp * scaler;
			return Convert.ToInt16(temp);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					this.Debug = Debug_Options.None;
					break;

				case 1:
					this.Debug = Debug_Options.Console;
					break;

				case 2:
					this.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					this.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		public void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("WeatherFlow - " + Station_ID + " - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("WeatherFlow - " + Station_ID + " - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
