﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Https;
using Newtonsoft.Json;

namespace WeatherFlowV2
{
	#region Delegates
	public delegate void DelegateFn1(SimplSharpString day_start_local, SimplSharpString day_num, SimplSharpString month_num, SimplSharpString conditions,
		SimplSharpString icon, SimplSharpString sunrise, SimplSharpString sunset, SimplSharpString air_temp_high, SimplSharpString air_temp_low, SimplSharpString precip_probability,
		SimplSharpString precip_icon, SimplSharpString precip_type);
	public delegate void DelegateFn2(SimplSharpString time, SimplSharpString conditions, SimplSharpString icon, SimplSharpString air_temperature, SimplSharpString sea_level_pressure,
		SimplSharpString relative_humidity, SimplSharpString precip, SimplSharpString precip_probability, SimplSharpString precip_type, SimplSharpString precip_icon, SimplSharpString wind_avg,
		SimplSharpString wind_direction, SimplSharpString wind_direction_cardinal, SimplSharpString wind_gust, SimplSharpString uv, SimplSharpString feels_like, SimplSharpString local_hour,
		SimplSharpString local_day);
	public delegate void DelegateFn3(short Daily_Count, short Hourly_Count);
	#endregion
	
	#region Enum
	enum Data_Format_Options
	{
		Metric,
		English
	};
	#endregion

	public class Forecast_Data_Integration
	{
		public DelegateFn1 dailey_fn { get; set; }
		public DelegateFn2 hourly_fn { get; set; }
		public DelegateFn3 data_counts_fn { get; set; }

		#region Declarations
		private string Station_ID;
		private string API_Key;
		private Data_Format_Options Data_Format;
		private Debug_Options Debug;
		Root Weather_Forecast;
		#endregion

		//****************************************************************************************
		// 
		//  Initialization	-	Called from s+ to start data collection
		// 
		//****************************************************************************************
		public void Forecast_Init(string Station_ID, string API_Key, short Data_Format, short Debug)
		{
			#region Check for proper configuration
			if (Station_ID == "")
			{
				CrestronConsole.PrintLine("Missing Station_ID for WeatherFlow Forecast Initialization");
				Crestron.SimplSharp.ErrorLog.Error("Missing Station_ID for WeatherFlow Forecast Initialization");
				return;
			}

			if (API_Key == "")
			{
				CrestronConsole.PrintLine("Missing Key for WeatherFlow Forecast Initialization");
				Crestron.SimplSharp.ErrorLog.Error("Missing Key for WeatherFlow Forecast Initialization");
				return;
			}
			#endregion

			#region Save Parameters to globals
			this.Station_ID = Station_ID;
			this.API_Key = API_Key;
			#region Data_Format
			switch (Data_Format)
			{
				case 0:
					this.Data_Format = Data_Format_Options.Metric;
					break;

				case 1:
					this.Data_Format = Data_Format_Options.English;
					break;

				default:
					Debug_Message("Initialization", "Unsupported Data Format = " + Data_Format);
					Debug_Message("Initialization", "Defaulting Data Format to English");
					this.Data_Format = Data_Format_Options.English;
					break;
			}
			#endregion
			Set_Debug_Message_Output(Debug);
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Forecast	-	Called from s+ to get forecast data
		// 
		//****************************************************************************************
		public void Get_Forecast()
		{
			Debug_Message("Get_Forecast", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "WeatherFlow Forecast - Get_Forecast - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}

			if ((string.IsNullOrEmpty(Station_ID)) || (Station_ID == "0"))
			{
				string err = "WeatherFlow Forecast - Get_Forecast - Station_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Create url
			string url = "https://swd.weatherflow.com/swd/rest/better_forecast?station_id=" + Station_ID + "&api_key=" + API_Key;
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "WeatherFlow Forecast - Get_Forecast - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Get_Forecast", "ContentString = " + response.ContentString);
					Weather_Forecast = JsonConvert.DeserializeObject<Root>(response.ContentString);
					Get_Daily_Forecast_Data(0);
					Get_Hourly_Forecast_Data(0);
					data_counts_fn(Convert.ToInt16(Weather_Forecast.forecast.daily.Count), Convert.ToInt16(Weather_Forecast.forecast.hourly.Count));
				}
			}
			catch (Exception e)
			{
				string err = "WeatherFlow Forecast - Get_Forecast - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Daily_Forecast_Data	-	
		// 
		//****************************************************************************************
		public short Get_Daily_Forecast_Data(short index)
		{
			string day_start_local; 
			string day_num;
			string month_num;
			string conditions;
			string icon;
			string sunrise;
			string sunset;
			string air_temp_high;
			string air_temp_low;
			string precip_probability;
			string precip_icon;
			string precip_type;

			Debug_Message("Get_Daily_Forecast_Data", "Index = " + index);

			#region Error Checking
			if (index >= Weather_Forecast.forecast.daily.Count)
			{
				string err = "Get_Daily_Forecast_Data - Invalid Day Index = " + index;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err);
				return 0;
			}
			#endregion

			day_start_local = To_Local_Time(Weather_Forecast.forecast.daily[index].day_start_local, true);
			day_num = Weather_Forecast.forecast.daily[index].day_num.ToString();
			month_num = Weather_Forecast.forecast.daily[index].month_num.ToString();
			conditions = Weather_Forecast.forecast.daily[index].conditions;
			icon = Weather_Forecast.forecast.daily[index].icon;
			sunrise = To_Local_Time(Weather_Forecast.forecast.daily[index].sunrise, false);
			sunset = To_Local_Time(Weather_Forecast.forecast.daily[index].sunset, false);
			air_temp_high = Format_Temperature(Weather_Forecast.forecast.daily[index].air_temp_high);
			air_temp_low = Format_Temperature(Weather_Forecast.forecast.daily[index].air_temp_low);
			precip_probability = Weather_Forecast.forecast.daily[index].precip_probability.ToString() + "%";
			precip_icon = Weather_Forecast.forecast.daily[index].precip_icon;
			precip_type = Weather_Forecast.forecast.daily[index].precip_type;

			dailey_fn(day_start_local, day_num, month_num, conditions, icon, sunrise, sunset, air_temp_high, air_temp_low, 
				precip_probability, precip_icon, precip_type);
			return 1;
		}

		//****************************************************************************************
		// 
		//  Get_Hourly_Forecast_Data	-	
		// 
		//****************************************************************************************
		public short Get_Hourly_Forecast_Data(short index)
		{
			string time;
			string conditions;
			string icon;
			string air_temperature;
			string sea_level_pressure;
			string relative_humidity;
			string precip;
			string precip_probability;
			string precip_type;
			string precip_icon;
			string wind_avg;
			string wind_direction;
			string wind_direction_cardinal;
			string wind_gust;
			string uv;
			string feels_like;
			string local_hour;
			string local_day;

			Debug_Message("Get_Hourly_Forecast_Data", "Index = " + index);

			#region Error Checking
			if (index >= Weather_Forecast.forecast.hourly.Count)
			{
				string err = "Get_Hourly_Forecast_Data - Invalid Hour Index = " + index;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err);
				return 0;
			}
			#endregion

			time = To_Local_Time(Weather_Forecast.forecast.hourly[index].time, false);
			conditions = Weather_Forecast.forecast.hourly[index].conditions;
			icon = Weather_Forecast.forecast.hourly[index].icon;
			air_temperature = Format_Temperature(Weather_Forecast.forecast.hourly[index].air_temperature);
			sea_level_pressure = Format_Pressure(Weather_Forecast.forecast.hourly[index].sea_level_pressure);
			relative_humidity = Weather_Forecast.forecast.hourly[index].relative_humidity + "%";
			precip = Format_Precip(Weather_Forecast.forecast.hourly[index].precip);
			precip_probability = Weather_Forecast.forecast.hourly[index].precip_probability + "%";
			precip_type = Weather_Forecast.forecast.hourly[index].precip_type;
			precip_icon = Weather_Forecast.forecast.hourly[index].precip_icon;
			wind_avg = Format_Wind_Speed(Weather_Forecast.forecast.hourly[index].wind_avg);
			wind_direction = Weather_Forecast.forecast.hourly[index].wind_direction.ToString() + " degrees";
			wind_direction_cardinal = Weather_Forecast.forecast.hourly[index].wind_direction_cardinal;
			wind_gust = Format_Wind_Speed(Weather_Forecast.forecast.hourly[index].wind_gust);
			uv = Weather_Forecast.forecast.hourly[index].uv.ToString() + " lux";
			feels_like = Format_Temperature(Weather_Forecast.forecast.hourly[index].feels_like);
			local_hour = Weather_Forecast.forecast.hourly[index].local_hour.ToString();
			local_day = Weather_Forecast.forecast.hourly[index].local_day.ToString();

			hourly_fn(time, conditions, icon, air_temperature, sea_level_pressure,
				relative_humidity, precip, precip_probability, precip_type, precip_icon, wind_avg,
				wind_direction, wind_direction_cardinal, wind_gust, uv, feels_like, local_hour,
				local_day);
			return 1;
		}

		//****************************************************************************************
		// 
		//  To_Local_Time	-	Convert from Unix Epoch time to local time string
		// 
		//****************************************************************************************
		private string To_Local_Time(int Unix_Time, bool date_only)
		{
			DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0);
			dateTime = dateTime.AddSeconds(Convert.ToDouble(Unix_Time));
			dateTime = dateTime.ToLocalTime();
			if (date_only == true)
			{
				if (this.Data_Format == Data_Format_Options.Metric)
				{
					return string.Format("{0:d-M-yyyy}", dateTime);
				}
				else
				{
					return string.Format("{0:M-d-yyyy}", dateTime);
				}
			}
			else
			{
				if (this.Data_Format == Data_Format_Options.Metric)
				{
					return string.Format("{0:d-M-yyyy}", dateTime) + " " + string.Format("{0:h:m tt}", dateTime);
				}
				else
				{
					return string.Format("{0:M-d-yyyy}", dateTime) + " " + string.Format("{0:h:m tt}", dateTime);
				}
			}
		}

		//****************************************************************************************
		// 
		//  Format_Temperature	-	format temperature in degrees f or c
		// 
		//****************************************************************************************
		private string Format_Temperature(double temp)
		{
			if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other == "metric"))
			{
				return Math.Round(temp, 0).ToString() + " C";
			}
			else if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other != "metric"))
			{
				double d = (temp - 32) / 1.8;
				return Math.Round(d, 0).ToString() + " C";
			}
			else if ((this.Data_Format == Data_Format_Options.English) && (Weather_Forecast.units.units_other == "metric"))
			{
				double d = (temp * 1.8) + 32;
				return Math.Round(d, 0).ToString() + " F";
			}
			else
			{
				return Math.Round(temp, 0).ToString() + " F";
			}
		}

		//****************************************************************************************
		// 
		//  Format_Precip	-	format amount of precipitation
		// 
		//****************************************************************************************
		private string Format_Precip(double distance)
		{
			if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other == "metric"))
			{
				return distance.ToString() + " mm";
			}
			else if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other != "metric"))
			{
				double d = distance * 25.4;
				d = Math.Round(d, 0);
				return d.ToString() + " mm";
			}
			else if ((this.Data_Format == Data_Format_Options.English) && (Weather_Forecast.units.units_other == "metric"))
			{
				double d = Convert.ToDouble(distance);
				d = d / 25.4;
				d = Math.Round(d, 2);
				return d.ToString() + " in";
			}
			else
			{
				return distance.ToString() + " in";
			}
		}

		//****************************************************************************************
		// 
		//  Format_Wind_Speed	-	format wind speed
		// 
		//****************************************************************************************
		private string Format_Wind_Speed(double speed)
		{
			if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other == "metric"))
			{
				return speed.ToString() + " mps";
			}
			else if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other != "metric"))
			{
				double d = speed / 2.237;
				d = Math.Round(d, 0);
				return d.ToString() + " mps";
			}
			else if ((this.Data_Format == Data_Format_Options.English) && (Weather_Forecast.units.units_other == "metric"))
			{
				double d = speed * 2.237;
				d = Math.Round(d, 0);
				return d.ToString() + " mph";
			}
			else
			{
				return speed.ToString() + " mph";
			}
		}

		//****************************************************************************************
		// 
		//  Format_Pressure	-	format pressure in mb or inhg
		// 
		//****************************************************************************************
		private string Format_Pressure(double pressure)
		{
			if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other == "metric"))
			{
				return pressure.ToString() + " mb";
			}
			else if ((this.Data_Format == Data_Format_Options.Metric) && (Weather_Forecast.units.units_other != "metric"))
			{
				double d = pressure * 33.864;
				d = Math.Round(d, 1);
				return d.ToString() + " mb";
			}
			else if ((this.Data_Format == Data_Format_Options.English) && (Weather_Forecast.units.units_other == "metric"))
			{
				double d = pressure / 33.864;
				d = Math.Round(d, 4);
				return d.ToString() + " inhg";
			}
			else
			{
				return pressure.ToString() + " inhg";
			}
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		private void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					this.Debug = Debug_Options.None;
					break;

				case 1:
					this.Debug = Debug_Options.Console;
					break;

				case 2:
					this.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					this.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("WeatherFlow Forecast - " + Station_ID + " - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("WeatherFlow Forecast - " + Station_ID + " - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	#region Forecast Classes
	public class CurrentConditions
	{
		public int time { get; set; }
		public string conditions { get; set; }
		public string icon { get; set; }
		public double air_temperature { get; set; }
		public double sea_level_pressure { get; set; }
		public double station_pressure { get; set; }
		public string pressure_trend { get; set; }
		public int relative_humidity { get; set; }
		public double wind_avg { get; set; }
		public int wind_direction { get; set; }
		public string wind_direction_cardinal { get; set; }
		public double wind_gust { get; set; }
		public int solar_radiation { get; set; }
		public int uv { get; set; }
		public int brightness { get; set; }
		public double feels_like { get; set; }
		public double dew_point { get; set; }
		public double wet_bulb_temperature { get; set; }
		public double wet_bulb_globe_temperature { get; set; }
		public double delta_t { get; set; }
		public double air_density { get; set; }
		public int lightning_strike_count_last_1hr { get; set; }
		public int lightning_strike_count_last_3hr { get; set; }
		public int lightning_strike_last_distance { get; set; }
		public string lightning_strike_last_distance_msg { get; set; }
		public int lightning_strike_last_epoch { get; set; }
		public int precip_accum_local_day { get; set; }
		public int precip_accum_local_yesterday { get; set; }
		public int precip_minutes_local_day { get; set; }
		public int precip_minutes_local_yesterday { get; set; }
		public bool is_precip_local_day_rain_check { get; set; }
		public bool is_precip_local_yesterday_rain_check { get; set; }
	}

	public class Daily
	{
		public int day_start_local { get; set; }
		public int day_num { get; set; }
		public int month_num { get; set; }
		public string conditions { get; set; }
		public string icon { get; set; }
		public int sunrise { get; set; }
		public int sunset { get; set; }
		public double air_temp_high { get; set; }
		public double air_temp_low { get; set; }
		public int precip_probability { get; set; }
		public string precip_icon { get; set; }
		public string precip_type { get; set; }
	}

	public class Forecast
	{
		public List<Daily> daily { get; set; }
		public List<Hourly> hourly { get; set; }
	}

	public class Hourly
	{
		public int time { get; set; }
		public string conditions { get; set; }
		public string icon { get; set; }
		public double air_temperature { get; set; }
		public double sea_level_pressure { get; set; }
		public int relative_humidity { get; set; }
		public double precip { get; set; }
		public int precip_probability { get; set; }
		public string precip_type { get; set; }
		public string precip_icon { get; set; }
		public double wind_avg { get; set; }
		public int wind_direction { get; set; }
		public string wind_direction_cardinal { get; set; }
		public double wind_gust { get; set; }
		public double uv { get; set; }
		public double feels_like { get; set; }
		public int local_hour { get; set; }
		public int local_day { get; set; }
	}

	public class Root
	{
		public double latitude { get; set; }
		public double longitude { get; set; }
		public string timezone { get; set; }
		public int timezone_offset_minutes { get; set; }
		public string location_name { get; set; }
		public CurrentConditions current_conditions { get; set; }
		public Forecast forecast { get; set; }
		public Status status { get; set; }
		public Units units { get; set; }
		public int source_id_conditions { get; set; }
	}

	public class Status
	{
		public int status_code { get; set; }
		public string status_message { get; set; }
	}

	public class Units
	{
		public string units_temp { get; set; }
		public string units_wind { get; set; }
		public string units_precip { get; set; }
		public string units_pressure { get; set; }
		public string units_distance { get; set; }
		public string units_brightness { get; set; }
		public string units_solar_radiation { get; set; }
		public string units_other { get; set; }
		public string units_air_density { get; set; }
	}
	#endregion
}