﻿using System.Reflection;

[assembly: AssemblyTitle("WeatherFlowV2")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("WeatherFlowV2")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion("1.0.0.*")]

