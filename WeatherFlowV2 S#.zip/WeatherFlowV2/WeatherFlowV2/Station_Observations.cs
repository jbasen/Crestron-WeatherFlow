﻿using System;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;
using Crestron.SimplSharp.Net.Https;
using Crestron.SimplSharp.CrestronSockets;
using System.Collections.Generic;

namespace WeatherFlowV2_Integration
{
	#region Delegates
	public delegate void DelegateFn(
		short temperature,
		ushort barometric_pressure,
		short dewpoint,
		short feels_like,
		short heat_index,
		ushort lightning_strike_count,
		ushort lightning_strike_count_last_1hr,
		ushort lightning_strike_count_last_3hr,
		ushort lightning_strike_last_distance,
		ushort lightning_strike_last_time,
		ushort precip,
		ushort precip_accum_last_1hr,
		ushort precip_accum_local_day,
		ushort precip_accum_local_day_final,
		ushort precip_accum_local_yesterday,
		ushort precip_accum_local_yesterday_final,
		ushort precip_minutes_local_day,
		ushort precip_minutes_local_yesterday,
		ushort precip_minutes_local_yesterday_final,
		SimplSharpString pressure_trend,
		ushort relative_humidity,
		ushort sea_level_pressure,
		ushort solar_radiation,
		ushort station_pressure,
		ushort uv,
		ushort wet_bulb_globe_temperature,
		ushort wet_bulb_temperature,
		ushort wind_avg,
		ushort wind_chill,
		ushort wind_direction,
		ushort wind_gust,
		ushort wind_lull,
		ushort brightness,

		SimplSharpString temperature_display_string,
		SimplSharpString barometric_pressure_display_string,
		SimplSharpString dewpoint_display_string,
		SimplSharpString feels_like_display_string,
		SimplSharpString heat_index_display_string,
		SimplSharpString lightning_strike_count_display_string,
		SimplSharpString lightning_strike_count_last_1hr_display_string,
		SimplSharpString lightning_strike_count_last_3hr_display_string,
		SimplSharpString lightning_strike_last_distance_display_string,
		SimplSharpString lightning_strike_last_time_display_string,
		SimplSharpString precip_display_string,
		SimplSharpString precip_accum_last_1hr_display_string,
		SimplSharpString precip_accum_local_day_display_string,
		SimplSharpString precip_accum_local_day_final_display_string,
		SimplSharpString precip_accum_local_yesterday_display_string,
		SimplSharpString precip_accum_local_yesterday_final_display_string,
		SimplSharpString precip_minutes_local_day_display_string,
		SimplSharpString precip_minutes_local_yesterday_display_string,
		SimplSharpString precip_minutes_local_yesterday_final_display_string,
		SimplSharpString relative_humidity_display_string,
		SimplSharpString sea_level_pressure_display_string,
		SimplSharpString solar_radiation_display_string,
		SimplSharpString station_pressure_display_string,
		SimplSharpString uv_display_string,
		SimplSharpString wet_bulb_globe_temperature_display_string,
		SimplSharpString wet_bulb_temperature_display_string,
		SimplSharpString wind_avg_display_string,
		SimplSharpString wind_chill_display_string,
		SimplSharpString wind_direction_display_string,
		SimplSharpString wind_gust_display_string,
		SimplSharpString wind_lull_display_string,
		SimplSharpString brightness_display_string
	);
	#endregion

	public class Station_Observations_Integration
	{
		public DelegateFn callback_fn { get; set; }

		#region Declarations
		private string Station_ID;
		private string API_Key;
		private Data_Format_Options Data_Format;
		private Debug_Options Debug;
		private const int Rounding_Fractional_Digits = 0;
		private long delay_between_calculations = 60000;						// 1 minute delay in msec 1 minute * 60 seconds * 1000 msec
		private CTimer cTimer = null; 
		private Display_Strings Display = null;
		#endregion

		//****************************************************************************************
		// 
		//  Initialization	-	Called from s+ to start data collection
		// 
		//****************************************************************************************
		public void Station_Observations_Init(string Station_ID, string API_Key, short Data_Format, short Debug)
		{
			#region Check for proper configuration
			if (Station_ID == "")
			{
				Debug_Message("Station_Data_Init", "Missing Station_ID for WeatherFlow Station Data Initialization");
				return;
			}

			if (API_Key == "")
			{
				Debug_Message("Station_Data_Init", "Missing Key for WeatherFlow Station Data Initialization");
				return;
			}
			#endregion

			#region Save Parameters to globals
			this.Station_ID = Station_ID;
			this.API_Key = API_Key;
			#region Data_Format
			switch (Data_Format)
			{
				case 0:
					this.Data_Format = Data_Format_Options.Metric;
					break;

				case 1:
					this.Data_Format = Data_Format_Options.English;
					break;

				default:
					Debug_Message("Initialization", "Unsupported Data Format = " + Data_Format);
					Debug_Message("Initialization", "Defaulting Data Format to English");
					this.Data_Format = Data_Format_Options.English;
					break;
			}
			#endregion
			Set_Debug_Message_Output(Debug);
			#endregion

			Set_Debug_Message_Output(Debug);

			#region Allocate Memory for Display Strings
			if (Display == null)
			{
				Display = new Display_Strings();
			}
			#endregion

			#region Start Timer to Get Data Every 30 Minutes
			if (cTimer == null)
			{
				try
				{
					CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Main_Timer_Thread);
					cTimer = new CTimer(Main_Timer_Thread, this, 0, delay_between_calculations);
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("WeatherFlow-Can't create timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("WeatherFlow-Can't create timer thread: " + e + "\n"));
					return;
				}
			}
			else
			{
				try
				{
					//restart timer that was previously stopped
					cTimer.Reset(0, delay_between_calculations);
				}
				catch (Exception e)
				{
					CrestronConsole.PrintLine(string.Format("WeatherFlow-Can't restart timer thread: " + e + "\n"));
					Crestron.SimplSharp.ErrorLog.Error(string.Format("WeatherFlow-Can't restart timer thread: " + e + "\n"));
					return;
				}
			}
			#endregion

		}

		//****************************************************************************************
		// 
		//  Main_Timer_Thread	-	Main Timer Thread
		// 
		//****************************************************************************************
		private void Main_Timer_Thread(Object unused)
		{
			string JSON = "";

			Debug_Message("Main_Timer_Thread", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				Debug_Message("Main_Timer_Thread", "API_Key Not Set");
				return;
			}

			if ((string.IsNullOrEmpty(Station_ID)) || (Station_ID == "0"))
			{
				Debug_Message("Main_Timer_Thread", "Station_ID Not Set");
				return;
			}
			#endregion

			#region Create url
			string url = "https://swd.weatherflow.com/swd/rest/observations/station/" + Station_ID + "?api_key=" + API_Key;
			#endregion

			#region Send Command
			// Create the client
			HttpsClient httpsClient = new HttpsClient();

			try
			{
				//turn verification off, to stop it taking a dump on cert errors
				httpsClient.HostVerification = false;
				httpsClient.PeerVerification = false;

				//create the request, populate it
				HttpsClientRequest httpsRequest = new HttpsClientRequest();
				HttpsClientResponse response;

				httpsRequest.Url.Parse(url);
				httpsRequest.RequestType = RequestType.Get;

				//attempt to dispatch the request
				response = httpsClient.Dispatch(httpsRequest);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					Debug_Message("Main_Timer_Thread", "http response code: " + response.Code);
				}
				else
				{
					JSON = response.ContentString;
					Debug_Message("Main_Timer_Thread", "ContentString = " + JSON);
					Station_Observations_Root Station_Observations = JsonConvert.DeserializeObject<Station_Observations_Root>(JSON);
					Convert_Data_To_Station_Unit_Format(ref Station_Observations);
					Create_Display_Strings(Station_Observations);
					Send_Data_To_Simpl(Station_Observations);
				}
			}
			catch (Exception ex)
			{
				string err = "WeatherFlow - Station_Data - Main_Timer_Thread - Error Sending Message (0) url = " + url;
				CrestronConsole.PrintLine(err);
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error(err);
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("WeatherFlow - Station_Data - Main_Timer_Thread - " + JSON);
				return;
			}
			finally
			{
				if (httpsClient != null)
				{
					httpsClient.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Convert_Data_To_Station_Unit_Format	-	Convert weather data based on Selected Format
		// 
		//****************************************************************************************
		private void Convert_Data_To_Station_Unit_Format(ref Station_Observations_Root Station_Observations)
		{
			if (Data_Format == Data_Format_Options.English)
			{
				//convert Air_Temperature from Celcius to Fahrenheit
				Station_Observations.obs[0].air_temperature = (Station_Observations.obs[0].air_temperature * 1.8) + 32;
				Station_Observations.obs[0].heat_index = (Station_Observations.obs[0].heat_index * 1.8) + 32;
				Station_Observations.obs[0].wind_chill = (Station_Observations.obs[0].wind_chill * 1.8) + 32;
				Station_Observations.obs[0].dew_point = (Station_Observations.obs[0].dew_point * 1.8) + 32;
				Station_Observations.obs[0].feels_like = (Station_Observations.obs[0].feels_like * 1.8) + 32;
				Station_Observations.obs[0].wet_bulb_globe_temperature = (Station_Observations.obs[0].wet_bulb_globe_temperature * 1.8) + 32;
				Station_Observations.obs[0].wet_bulb_temperature = (Station_Observations.obs[0].wet_bulb_temperature * 1.8) + 32;

				// Convert Pressure from mb to inhg
				Station_Observations.obs[0].barometric_pressure /= 33.864;
				Station_Observations.obs[0].station_pressure /= 33.864;
				Station_Observations.obs[0].sea_level_pressure /= 33.864;

				// Convert Precipitation from mm to inches
				Station_Observations.obs[0].precip /= 25.4;
				Station_Observations.obs[0].precip_accum_last_1hr /= 25.4;
				Station_Observations.obs[0].precip_accum_local_day /= 25.4;
				Station_Observations.obs[0].precip_accum_local_day_final /= 25.4;
				Station_Observations.obs[0].precip_accum_local_yesterday /= 25.4;
				Station_Observations.obs[0].precip_accum_local_yesterday_final /= 25.4;

				// Convert Wind from Meters/Second to MPH
				Station_Observations.obs[0].wind_avg *= 2.237;
				Station_Observations.obs[0].wind_gust *= 2.237;
				Station_Observations.obs[0].wind_lull *= 2.237;

				// Convert Lightening Distance from Km to Miles
				double temp = (Convert.ToDouble(Station_Observations.obs[0].lightning_strike_last_distance)) / 1.609;
				Station_Observations.obs[0].lightning_strike_last_distance = Convert.ToInt32(Math.Round(temp, Rounding_Fractional_Digits));
			}

			//Scale Data for Passing to Simpl
			Station_Observations.obs[0].air_temperature = Math.Round(Station_Observations.obs[0].air_temperature * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].barometric_pressure = Math.Round(Station_Observations.obs[0].barometric_pressure * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].heat_index = Math.Round(Station_Observations.obs[0].heat_index * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].wind_chill = Math.Round(Station_Observations.obs[0].wind_chill * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].dew_point = Math.Round(Station_Observations.obs[0].dew_point * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].feels_like = Math.Round(Station_Observations.obs[0].feels_like * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].station_pressure = Math.Round(Station_Observations.obs[0].station_pressure * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].sea_level_pressure = Math.Round(Station_Observations.obs[0].sea_level_pressure * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].precip = Math.Round(Station_Observations.obs[0].precip * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].precip_accum_last_1hr = Math.Round(Station_Observations.obs[0].precip_accum_last_1hr * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].precip_accum_local_day = Math.Round(Station_Observations.obs[0].precip_accum_local_day * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].precip_accum_local_day_final = Math.Round(Station_Observations.obs[0].precip_accum_local_day_final * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].precip_accum_local_yesterday = Math.Round(Station_Observations.obs[0].precip_accum_local_yesterday * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].precip_accum_local_yesterday_final = Math.Round(Station_Observations.obs[0].precip_accum_local_yesterday_final * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].wind_avg = Math.Round(Station_Observations.obs[0].wind_avg * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].wind_gust = Math.Round(Station_Observations.obs[0].wind_gust * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].wind_lull = Math.Round(Station_Observations.obs[0].wind_lull * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].wet_bulb_globe_temperature = Math.Round(Station_Observations.obs[0].wet_bulb_globe_temperature * 10, Rounding_Fractional_Digits);
			Station_Observations.obs[0].wet_bulb_temperature = Math.Round(Station_Observations.obs[0].wet_bulb_temperature * 10, Rounding_Fractional_Digits);
		}

		//****************************************************************************************
		// 
		//  Create_Display_Strings	-	Create Strings for Display on a TP
		// 
		//****************************************************************************************
		private void Create_Display_Strings(Station_Observations_Root Station_Observations)
		{
			string temp_unit;
			string pressure_unit;
			string distance_unit;
			string precip_unit;
			string wind_unit;
			DateTime dt;

			if (Data_Format == Data_Format_Options.English)
			{
				temp_unit = " F";
				pressure_unit = " inhg";
				distance_unit = " mi";
				precip_unit = " in";
				wind_unit = " mph";
			}
			else
			{
				temp_unit = " C";
				pressure_unit = " mb";
				distance_unit = " km";
				precip_unit = " mm";
				wind_unit = " m/s";
			}

			Display.air_temperature_display_string = (Station_Observations.obs[0].air_temperature / 10).ToString() + temp_unit;
			Display.barometric_pressure_display_string = (Station_Observations.obs[0].barometric_pressure / 10).ToString() + pressure_unit;
			Display.dewpoint_display_string = (Station_Observations.obs[0].dew_point /10).ToString() + temp_unit;
			Display.feels_like_display_string = (Station_Observations.obs[0].feels_like / 10).ToString() + temp_unit;
			Display.heat_index_display_string = (Station_Observations.obs[0].heat_index / 10).ToString() + temp_unit;
			Display.lightning_strike_count_display_string = Station_Observations.obs[0].lightning_strike_count.ToString();
			Display.lightning_strike_count_last_1hr_display_string = Station_Observations.obs[0].lightning_strike_count_last_1hr.ToString();
			Display.lightning_strike_count_last_3hr_display_string = Station_Observations.obs[0].lightning_strike_count_last_3hr.ToString();
			Display.lightning_strike_last_distance_display_string = Station_Observations.obs[0].lightning_strike_last_distance.ToString() + distance_unit;

			dt = Epoch_Conversion(Station_Observations.obs[0].lightning_strike_last_epoch);
			Display.lightning_strike_last_time_display_string = dt.ToString("MM/dd/yyyy hh:mm tt");

			Display.precip_display_string = (Station_Observations.obs[0].precip / 10).ToString() + precip_unit;
			Display.precip_accum_last_1hr_display_string = (Station_Observations.obs[0].precip_accum_last_1hr / 10).ToString() + precip_unit;
			Display.precip_accum_local_day_display_string = (Station_Observations.obs[0].precip_accum_local_day / 10).ToString() + precip_unit;
			Display.precip_accum_local_day_final_display_string = (Station_Observations.obs[0].precip_accum_local_day_final / 10).ToString() + precip_unit;
			Display.precip_accum_local_yesterday_display_string = (Station_Observations.obs[0].precip_accum_local_yesterday / 10).ToString() + precip_unit;
			Display.precip_accum_local_yesterday_final_display_string = (Station_Observations.obs[0].precip_accum_local_yesterday_final / 10).ToString() + precip_unit;
			Display.precip_minutes_local_day_display_string = Station_Observations.obs[0].precip_minutes_local_day.ToString() + " minutes";
			Display.precip_minutes_local_yesterday_display_string = Station_Observations.obs[0].precip_minutes_local_yesterday.ToString() + " minutes";
			Display.precip_minutes_local_yesterday_final_display_string = Station_Observations.obs[0].precip_minutes_local_yesterday_final.ToString() + "minutes";
			Display.relative_humidity_display_string = Station_Observations.obs[0].relative_humidity.ToString() + " %";
			Display.sea_level_pressure_display_string = (Station_Observations.obs[0].sea_level_pressure / 10).ToString() + pressure_unit;
			Display.solar_radiation_display_string = Station_Observations.obs[0].solar_radiation.ToString() + " W/m^2";
			Display.station_pressure_display_string = (Station_Observations.obs[0].station_pressure / 10).ToString() + pressure_unit;
			Display.uv_display_string = Station_Observations.obs[0].uv.ToString();
			Display.wet_bulb_globe_temperature_display_string = (Station_Observations.obs[0].wet_bulb_globe_temperature / 10).ToString() + temp_unit;
			Display.wet_bulb_temperature_display_string = (Station_Observations.obs[0].wet_bulb_temperature / 10).ToString() + temp_unit;
			Display.wind_avg_display_string = (Station_Observations.obs[0].wind_avg / 10).ToString() + wind_unit;
			Display.wind_chill_display_string = (Station_Observations.obs[0].wind_chill / 10).ToString() + temp_unit;
			Display.wind_direction_display_string = Degrees_To_Cardinal_Direction(Station_Observations.obs[0].wind_direction);
			Display.wind_gust_display_string = (Station_Observations.obs[0].wind_gust / 10).ToString() + wind_unit;
			Display.wind_lull_display_string = (Station_Observations.obs[0].wind_lull / 10).ToString() + wind_unit;
			Display.brightness_display_string = (Station_Observations.obs[0].brightness.ToString()) + " Lux";
		}

		//****************************************************************************************
		// 
		//  Send_Data_To_Simpl	-	
		// 
		//****************************************************************************************
		private void Send_Data_To_Simpl(Station_Observations_Root Station_Observations)
		{
			short temperature = Convert.ToInt16(Station_Observations.obs[0].air_temperature);
			ushort barometric_pressure = Convert.ToUInt16(Station_Observations.obs[0].station_pressure);
			short dewpoint = Convert.ToInt16(Station_Observations.obs[0].dew_point);
			short feels_like = Convert.ToInt16(Station_Observations.obs[0].feels_like);
			short heat_index = Convert.ToInt16(Station_Observations.obs[0].heat_index);
			ushort lightning_strike_count = Convert.ToUInt16(Station_Observations.obs[0].lightning_strike_count);
			ushort lightning_strike_count_last_1hr = Convert.ToUInt16(Station_Observations.obs[0].lightning_strike_count_last_1hr);
			ushort lightning_strike_count_last_3hr = Convert.ToUInt16(Station_Observations.obs[0].lightning_strike_count_last_3hr);
			ushort lightning_strike_last_distance = Convert.ToUInt16(Station_Observations.obs[0].lightning_strike_last_distance);
			ushort lightning_strike_last_time = 0;
			ushort precip = Convert.ToUInt16(Station_Observations.obs[0].precip);
			ushort precip_accum_last_1hr = Convert.ToUInt16(Station_Observations.obs[0].precip_accum_last_1hr);
			ushort precip_accum_local_day = Convert.ToUInt16(Station_Observations.obs[0].precip_accum_local_day);
			ushort precip_accum_local_day_final = Convert.ToUInt16(Station_Observations.obs[0].precip_accum_local_day_final);
			ushort precip_accum_local_yesterday = Convert.ToUInt16(Station_Observations.obs[0].precip_accum_local_yesterday);
			ushort precip_accum_local_yesterday_final = Convert.ToUInt16(Station_Observations.obs[0].precip_accum_local_yesterday_final);
			ushort precip_analysis_type_yesterday = Convert.ToUInt16(Station_Observations.obs[0].precip_analysis_type_yesterday);
			ushort precip_minutes_local_day = Convert.ToUInt16(Station_Observations.obs[0].precip_minutes_local_day);
			ushort precip_minutes_local_yesterday = Convert.ToUInt16(Station_Observations.obs[0].precip_minutes_local_yesterday);
			ushort precip_minutes_local_yesterday_final = Convert.ToUInt16(Station_Observations.obs[0].precip_minutes_local_yesterday_final);
			string pressure_trend = Station_Observations.obs[0].pressure_trend;
			ushort relative_humidity = Convert.ToUInt16(Station_Observations.obs[0].relative_humidity);
			ushort sea_level_pressure = Convert.ToUInt16(Station_Observations.obs[0].sea_level_pressure);
			ushort solar_radiation = Convert.ToUInt16(Station_Observations.obs[0].solar_radiation);
			ushort station_pressure = Convert.ToUInt16(Station_Observations.obs[0].station_pressure);
			ushort uv = Convert.ToUInt16(Station_Observations.obs[0].uv);
			ushort wet_bulb_globe_temperature = Convert.ToUInt16(Station_Observations.obs[0].wet_bulb_globe_temperature);
			ushort wet_bulb_temperature = Convert.ToUInt16(Station_Observations.obs[0].wet_bulb_temperature);
			ushort wind_avg = Convert.ToUInt16(Station_Observations.obs[0].wind_avg);
			ushort wind_chill = Convert.ToUInt16(Station_Observations.obs[0].wind_chill);
			ushort wind_direction = Convert.ToUInt16(Station_Observations.obs[0].wind_direction);
			ushort wind_gust = Convert.ToUInt16(Station_Observations.obs[0].wind_gust);
			ushort wind_lull = Convert.ToUInt16(Station_Observations.obs[0].wind_lull);
			ushort brightness = Convert.ToUInt16(Station_Observations.obs[0].brightness / 10);

			callback_fn(temperature, barometric_pressure, dewpoint, feels_like, heat_index, lightning_strike_count,
				lightning_strike_count_last_1hr, lightning_strike_count_last_3hr, lightning_strike_last_distance, lightning_strike_last_time,
				precip, precip_accum_last_1hr, precip_accum_local_day, precip_accum_local_day_final, precip_accum_local_yesterday,
				precip_accum_local_yesterday_final, precip_minutes_local_day, precip_minutes_local_yesterday,
				precip_minutes_local_yesterday_final, pressure_trend, relative_humidity, sea_level_pressure, solar_radiation, station_pressure,
				uv, wet_bulb_globe_temperature, wet_bulb_temperature, wind_avg, wind_chill, wind_direction, wind_gust, wind_lull, brightness,
				Display.air_temperature_display_string, Display.barometric_pressure_display_string, Display.dewpoint_display_string,
				Display.feels_like_display_string, Display.heat_index_display_string, Display.lightning_strike_count_display_string,
				Display.lightning_strike_count_last_1hr_display_string, Display.lightning_strike_count_last_3hr_display_string,
				Display.lightning_strike_last_distance_display_string, Display.lightning_strike_last_time_display_string,
				Display.precip_display_string, Display.precip_accum_last_1hr_display_string, Display.precip_accum_local_day_display_string,
				Display.precip_accum_local_day_final_display_string, Display.precip_accum_local_yesterday_display_string,
				Display.precip_accum_local_yesterday_final_display_string, Display.precip_minutes_local_day_display_string,
				Display.precip_minutes_local_yesterday_display_string, Display.precip_minutes_local_yesterday_final_display_string,
				Display.relative_humidity_display_string, Display.sea_level_pressure_display_string, Display.solar_radiation_display_string,
				Display.station_pressure_display_string, Display.uv_display_string, Display.wet_bulb_globe_temperature_display_string, 
				Display.wet_bulb_temperature_display_string, Display.wind_avg_display_string, Display.wind_chill_display_string,
				Display.wind_direction_display_string, Display.wind_gust_display_string, Display.wind_lull_display_string, 
				Display.brightness_display_string);
		}

		//****************************************************************************************
		// 
		//  Epoch_Conversion	-   
		// 
		//****************************************************************************************
		private static DateTime Epoch_Conversion(double Epoch)
		{
			// Unix timestamp is seconds past epoch
			DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
			dtDateTime = dtDateTime.AddSeconds(Convert.ToInt32(Epoch)).ToLocalTime();

			return dtDateTime;
		}

		//****************************************************************************************
		// 
		//  Degrees_To_Cardinal_Direction	-	Convert from Degrees to Cardinal Direction
		// 
		//****************************************************************************************
		private static string Degrees_To_Cardinal_Direction(int degrees)
		{
			if ((degrees >= 348.75) && (degrees < 11.25))
			{
				return "N";
			}
			else if ((degrees >= 11.25) && (degrees < 33.75))
			{
				return "NNE";
			}
			else if ((degrees >= 33.75) && (degrees < 56.25))
			{
				return "NE";
			}
			else if ((degrees >= 56.25) && (degrees < 78.75))
			{
				return "ENE";
			}
			else if ((degrees >= 78.75) && (degrees < 101.25))
			{
				return "E";
			}
			else if ((degrees >= 101.25) && (degrees < 123.75))
			{
				return "ESE";
			}
			else if ((degrees >= 123.75) && (degrees < 146.25))
			{
				return "SE";
			}
			else if ((degrees >= 146.25) && (degrees < 168.75))
			{
				return "SSE";
			}
			else if ((degrees >= 168.75) && (degrees < 191.25))
			{
				return "S";
			}
			else if ((degrees >= 191.25) && (degrees < 213.75))
			{
				return "SSW";
			}
			else if ((degrees >= 213.75) && (degrees < 236.25))
			{
				return "SW";
			}
			else if ((degrees >= 236.25) && (degrees < 258.75))
			{
				return "WSW";
			}
			else if ((degrees >= 258.75) && (degrees < 281.25))
			{
				return "W";
			}
			else if ((degrees >= 281.25) && (degrees < 303.75))
			{
				return "WNW";
			}
			else if ((degrees >= 303.75) && (degrees < 326.25))
			{
				return "NW";
			}
			else if ((degrees >= 326.25) && (degrees < 348.75))
			{
				return "NNW";
			}
			else
			{
				return degrees.ToString() + " Degrees";
			}
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		private void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					this.Debug = Debug_Options.None;
					break;

				case 1:
					this.Debug = Debug_Options.Console;
					break;

				case 2:
					this.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					this.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("WeatherFlow Station Data - " + Station_ID + " - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("WeatherFlow Station Data - " + Station_ID + " - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	#region Station Data Classes
	public class Station_Observations_Root
	{
		public double elevation { get; set; }
		public bool is_public { get; set; }
		public double latitude { get; set; }
		public double longitude { get; set; }
		public List<Ob> obs { get; set; }
		public List<string> outdoor_keys { get; set; }
		public string public_name { get; set; }
		public int station_id { get; set; }
		public string station_name { get; set; }
		public StationUnits station_units { get; set; }
		public Station_Status status { get; set; }
		public string timezone { get; set; }
	}

	public class Ob
	{
		public double air_density { get; set; }
		public double air_temperature { get; set; }
		public double barometric_pressure { get; set; }
		public int brightness { get; set; }
		public double delta_t { get; set; }
		public double dew_point { get; set; }
		public double feels_like { get; set; }
		public double heat_index { get; set; }
		public int lightning_strike_count { get; set; }
		public int lightning_strike_count_last_1hr { get; set; }
		public int lightning_strike_count_last_3hr { get; set; }
		public int lightning_strike_last_distance { get; set; }
		public int lightning_strike_last_epoch { get; set; }
		public double precip { get; set; }
		public double precip_accum_last_1hr { get; set; }
		public double precip_accum_local_day { get; set; }
		public double precip_accum_local_day_final { get; set; }
		public double precip_accum_local_yesterday { get; set; }
		public double precip_accum_local_yesterday_final { get; set; }
		public int precip_analysis_type_yesterday { get; set; }
		public int precip_minutes_local_day { get; set; }
		public int precip_minutes_local_yesterday { get; set; }
		public int precip_minutes_local_yesterday_final { get; set; }
		public string pressure_trend { get; set; }
		public int relative_humidity { get; set; }
		public double sea_level_pressure { get; set; }
		public int solar_radiation { get; set; }
		public double station_pressure { get; set; }
		public int timestamp { get; set; }
		public double uv { get; set; }
		public double wet_bulb_globe_temperature { get; set; }
		public double wet_bulb_temperature { get; set; }
		public double wind_avg { get; set; }
		public double wind_chill { get; set; }
		public int wind_direction { get; set; }
		public double wind_gust { get; set; }
		public double wind_lull { get; set; }
	}

	public class StationUnits
	{
		public string units_direction { get; set; }
		public string units_distance { get; set; }
		public string units_other { get; set; }
		public string units_precip { get; set; }
		public string units_pressure { get; set; }
		public string units_temp { get; set; }
		public string units_wind { get; set; }
	}

	public class Station_Status
	{
		public int status_code { get; set; }
		public string status_message { get; set; }
	}

	public class Display_Strings
	{
		public string air_temperature_display_string { get; set; }
		public string barometric_pressure_display_string { get; set; }
		public string brightness_display_string { get; set; }
		public string delta_t_display_string { get; set; }
		public string dewpoint_display_string { get; set; }
		public string feels_like_display_string { get; set; }
		public string heat_index_display_string { get; set; }
		public string lightning_strike_count_display_string { get; set; }
		public string lightning_strike_count_last_1hr_display_string { get; set; }
		public string lightning_strike_count_last_3hr_display_string { get; set; }
		public string lightning_strike_last_distance_display_string { get; set; }
		public string lightning_strike_last_time_display_string { get; set; }
		public string precip_display_string { get; set; }
		public string precip_accum_last_1hr_display_string { get; set; }
		public string precip_accum_local_day_display_string { get; set; }
		public string precip_accum_local_day_final_display_string { get; set; }
		public string precip_accum_local_yesterday_display_string { get; set; }
		public string precip_accum_local_yesterday_final_display_string { get; set; }
		public string precip_minutes_local_day_display_string { get; set; }
		public string precip_minutes_local_yesterday_display_string { get; set; }
		public string precip_minutes_local_yesterday_final_display_string { get; set; }
		public string relative_humidity_display_string { get; set; }
		public string sea_level_pressure_display_string { get; set; }
		public string solar_radiation_display_string { get; set; }
		public string station_pressure_display_string { get; set; }
		public string timestamp_display_string { get; set; }
		public string uv_display_string { get; set; }
		public string wet_bulb_globe_temperature_display_string { get; set; }
		public string wet_bulb_temperature_display_string { get; set; }
		public string wind_avg_display_string { get; set; }
		public string wind_chill_display_string { get; set; }
		public string wind_direction_display_string { get; set; }
		public string wind_gust_display_string { get; set; }
		public string wind_lull_display_string { get; set; }
	}
	#endregion
}